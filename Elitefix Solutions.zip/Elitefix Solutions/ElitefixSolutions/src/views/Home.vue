<template>
  <Navbar />
  <HeroSection />
  <ServicesSection />
  <WhyChooseUs />
  <StatsSection />
  <QuoteSection />
  <Footer />
</template>

<script setup>
import Navbar from "@/components/Navbar.vue";
import HeroSection from "@/components/HeroSection.vue";
import ServicesSection from "@/components/ServicesSection.vue";
import WhyChooseUs from "@/components/WhyChooseUs.vue";
import StatsSection from "@/components/StatsSection.vue";
import QuoteSection from "@/components/RequestQuoteSection.vue";
import Footer from "@/components/Footer.vue";
</script>