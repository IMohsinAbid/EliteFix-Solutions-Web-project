<template>

  <Navbar/>

  <!-- Hero -->

  <section class="hero">

    <div class="overlay">

      <h4>SOIL WORK & MAINTENANCE</h4>

      <h1>
        Professional Soil Work &
        Civil Maintenance Services
      </h1>

      <p>

        We provide excavation, land preparation,
        trenching and civil maintenance services
        for residential and commercial projects
        across Dubai.

      </p>

    </div>

  </section>

  <!-- About -->

  <section class="service">

    <div class="image">


    </div>

    <div class="content">

      <h5>ABOUT OUR SERVICE</h5>

      <h2>

        Reliable Soil &
        Ground Preparation

      </h2>

      <p>

        EliteFix Solutions offers professional
        soil work, excavation, trenching and
        site preparation services using modern
        machinery and experienced operators.

      </p>

      <div class="list">

        <div>✔ Land Leveling</div>

        <div>✔ Excavation Work</div>

        <div>✔ Foundation Preparation</div>

        <div>✔ Trenching</div>

        <div>✔ Site Cleaning</div>

        <div>✔ Civil Maintenance</div>

      </div>

    </div>

  </section>

  <!-- Benefits -->

  <section class="benefits">

    <h2>

      Why Choose Our Soil Work?

    </h2>

    <div class="cards">

      <div class="card">

        🚜

        <h3>Modern Machinery</h3>

        <p>

          Efficient excavation and
          land preparation equipment.

        </p>

      </div>

      <div class="card">

        👷

        <h3>Experienced Team</h3>

        <p>

          Skilled operators and
          site supervisors.

        </p>

      </div>

      <div class="card">

        📐

        <h3>Accurate Planning</h3>

        <p>

          Precision work with
          quality assurance.

        </p>

      </div>

    </div>

  </section>

  <!-- Process -->

  <section class="process">

    <h2>

      Our Working Process

    </h2>

    <div class="steps">

      <div>1️⃣ Site Visit</div>

      <div>2️⃣ Planning</div>

      <div>3️⃣ Excavation</div>

      <div>4️⃣ Final Inspection</div>

    </div>

  </section>

  <!-- Gallery -->

  <section class="gallery">

    <h2>

      Recent Soil Work Projects

    </h2>

    <div class="grid">

 

    </div>

  </section>

  <!-- FAQ -->

  <section class="faq">

    <h2>

      Frequently Asked Questions

    </h2>

    <div class="question">

      <h3>

        Do you provide excavation services?

      </h3>

      <p>

        Yes. We handle excavation for
        residential and commercial projects.

      </p>

    </div>

    <div class="question">

      <h3>

        Can you prepare land before construction?

      </h3>

      <p>

        Yes. We provide complete land
        preparation and foundation work.

      </p>

    </div>

    <div class="question">

      <h3>

        Do you provide site cleaning?

      </h3>

      <p>

        Yes. We offer site clearing,
        debris removal and maintenance.

      </p>

    </div>

  </section>

  <RequestQuoteSection/>

  <Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

.hero{
height:55vh;
background:url('/images/services/soil-work/banner.jpg') center/cover no-repeat;
}

.overlay{
height:100%;
background:rgba(8,26,56,.75);
display:flex;
flex-direction:column;
justify-content:center;
align-items:center;
text-align:center;
padding:20px;
color:white;
}

.overlay h4{
color:#ff6b00;
letter-spacing:2px;
}

.overlay h1{
font-size:48px;
margin:20px 0;
}

.overlay p{
max-width:700px;
line-height:1.8;
}

.service{
padding:100px 8%;
display:grid;
grid-template-columns:1fr 1fr;
gap:60px;
align-items:center;
}

.service img{
width:100%;
border-radius:18px;
}

.content h5{
color:#ff6b00;
}

.content h2{
font-size:42px;
margin:20px 0;
color:#081A38;
}

.content p{
line-height:1.8;
color:#666;
}

.list{
margin-top:30px;
display:grid;
grid-template-columns:repeat(2,1fr);
gap:18px;
font-weight:600;
}

.benefits{
padding:100px 8%;
background:#f8f9fb;
text-align:center;
}

.cards{
display:grid;
grid-template-columns:repeat(3,1fr);
gap:30px;
margin-top:40px;
}

.card{
background:white;
padding:40px;
border-radius:18px;
box-shadow:0 10px 25px rgba(0,0,0,.08);
}

.card h3{
margin:20px 0;
color:#081A38;
}

.process{
padding:100px 8%;
text-align:center;
}

.steps{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
margin-top:40px;
}

.steps div{
background:#081A38;
color:white;
padding:30px;
border-radius:15px;
font-weight:bold;
}

.gallery{
padding:100px 8%;
}

.gallery h2{
text-align:center;
margin-bottom:40px;
}

.grid{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
}

.grid img{
width:100%;
height:250px;
object-fit:cover;
border-radius:15px;
}

.faq{
padding:100px 8%;
}

.question{
background:#f7f8fa;
padding:25px;
margin-bottom:20px;
border-radius:12px;
}

@media(max-width:992px){

.service{
grid-template-columns:1fr;
}

.cards{
grid-template-columns:1fr;
}

.steps{
grid-template-columns:1fr;
}

.grid{
grid-template-columns:1fr;
}

.overlay h1{
font-size:34px;
}

.list{
grid-template-columns:1fr;
}

}

</style>