<template>

  <Navbar />

  <!-- Hero Banner -->
  <section class="about-hero">

    <div class="overlay">

      <h4>ABOUT ELITEFIX SOLUTIONS</h4>

      <h1>
        Trusted Home Maintenance &
        Technical Services in Dubai
      </h1>

      <p>
        We deliver reliable maintenance, renovation,
        and repair services for homes and businesses
        across Dubai.
      </p>

    </div>

  </section>

  <!-- Company Story -->

  <section class="about">

    <div class="about-image">


    </div>

    <div class="about-content">

      <span>WHO WE ARE</span>

      <h2>
        Your Trusted Partner for
        Home Maintenance
      </h2>

      <p>

        EliteFix Solutions is a Dubai-based technical
        services company providing professional AC
        maintenance, plumbing, electrical services,
        home maintenance, soil work, and media wall
        installation.

      </p>

      <p>

        Our experienced technicians are committed to
        delivering quality workmanship, timely service,
        and complete customer satisfaction.

      </p>

      <div class="features">

        <div>✔ Certified Technicians</div>

        <div>✔ Affordable Pricing</div>

        <div>✔ Same Day Service</div>

        <div>✔ Quality Guaranteed</div>

      </div>

    </div>

  </section>

  <!-- Mission Vision -->

  <section class="mission">

    <div class="card">

      <h3>🎯 Our Mission</h3>

      <p>

        To provide dependable, affordable,
        and high-quality maintenance services
        that exceed customer expectations.

      </p>

    </div>

    <div class="card">

      <h3>👁 Our Vision</h3>

      <p>

        To become Dubai's most trusted
        home maintenance company through
        innovation and professionalism.

      </p>

    </div>

  </section>

  <!-- Reusable Components -->

  <WhyChooseUs />

  <StatsSection />

  <RequestQuoteSection />

  <Footer />

</template>

<script setup>

import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

import WhyChooseUs from "@/components/WhyChooseUs.vue";
import StatsSection from "@/components/StatsSection.vue";
import RequestQuoteSection from "@/components/RequestQuoteSection.vue";

</script>

<style scoped>

.about-hero{

height:55vh;

background:url('/images/about-banner.jpg');

background-size:cover;

background-position:center;

position:relative;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

text-align:center;

color:white;

padding:30px;

}

.overlay h4{

color:#ff6b00;

margin-bottom:20px;

letter-spacing:2px;

}

.overlay h1{

font-size:48px;

max-width:900px;

margin-bottom:20px;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.about{

padding:100px 8%;

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

align-items:center;

}

.about-image img{

width:100%;

border-radius:20px;

}

.about-content span{

color:#ff6b00;

font-weight:bold;

}

.about-content h2{

font-size:42px;

margin:20px 0;

color:#081A38;

}

.about-content p{

line-height:1.9;

color:#666;

margin-bottom:20px;

}

.features{

display:grid;

grid-template-columns:1fr 1fr;

gap:20px;

margin-top:30px;

font-weight:600;

}

.mission{

padding:0 8% 100px;

display:grid;

grid-template-columns:1fr 1fr;

gap:40px;

}

.card{

padding:40px;

background:#fff;

border-radius:18px;

box-shadow:0 10px 30px rgba(0,0,0,.08);

}

.card h3{

color:#081A38;

margin-bottom:20px;

font-size:28px;

}

.card p{

line-height:1.8;

color:#666;

}

@media(max-width:992px){

.about{

grid-template-columns:1fr;

}

.mission{

grid-template-columns:1fr;

}

.overlay h1{

font-size:36px;

}

.features{

grid-template-columns:1fr;

}

}

</style>