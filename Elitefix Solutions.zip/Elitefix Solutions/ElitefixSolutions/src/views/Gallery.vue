<template>

<Navbar/>

<!-- Hero -->

<section class="hero">

    <div class="overlay">

        <h4>OUR GALLERY</h4>

        <h1>
            Our Recent Projects
        </h1>

        <p>

            Explore our completed maintenance,
            renovation and installation projects
            across Dubai.

        </p>

    </div>

</section>

<!-- Intro -->

<section class="intro">

<h2>

Quality Work You Can Trust

</h2>

<p>

Every project reflects our commitment
to quality workmanship, professionalism,
and customer satisfaction.

</p>

</section>

<!-- Gallery -->

<section class="gallery">

<div

class="card"

v-for="item in gallery"

:key="item.title"

>


<div class="content">

<span>

{{item.category}}

</span>

<h3>

{{item.title}}

</h3>

</div>

</div>

</section>

<RequestQuoteSection/>

<Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

const gallery=[

{
title:"AC Maintenance",
category:"Air Conditioning",
image:"/images/gallery/ac1.jpg"
},

{
title:"AC Installation",
category:"Air Conditioning",
image:"/images/gallery/ac2.jpg"
},

{
title:"Bathroom Plumbing",
category:"Plumbing",
image:"/images/gallery/plumbing1.jpg"
},

{
title:"Kitchen Plumbing",
category:"Plumbing",
image:"/images/gallery/plumbing2.jpg"
},

{
title:"Electrical Wiring",
category:"Electrical",
image:"/images/gallery/electrical1.jpg"
},

{
title:"LED Lighting",
category:"Electrical",
image:"/images/gallery/electrical2.jpg"
},

{
title:"Villa Maintenance",
category:"Home Maintenance",
image:"/images/gallery/home1.jpg"
},

{
title:"Painting Work",
category:"Home Maintenance",
image:"/images/gallery/home2.jpg"
},

{
title:"Land Excavation",
category:"Soil Work",
image:"/images/gallery/soil1.jpg"
},

{
title:"Foundation Work",
category:"Soil Work",
image:"/images/gallery/soil2.jpg"
},

{
title:"Modern TV Wall",
category:"Media Wall",
image:"/images/gallery/media1.jpg"
},

{
title:"Luxury Media Wall",
category:"Media Wall",
image:"/images/gallery/media2.jpg"
}

]

</script>

<style scoped>

.hero{

height:55vh;

background:url('/images/gallery/gallery-banner.jpg');

background-size:cover;

background-position:center;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

text-align:center;

color:white;

padding:20px;

}

.overlay h4{

color:#ff6b00;

letter-spacing:2px;

margin-bottom:15px;

}

.overlay h1{

font-size:50px;

margin-bottom:20px;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.intro{

padding:80px 8%;

text-align:center;

}

.intro h2{

font-size:40px;

color:#081A38;

margin-bottom:20px;

}

.intro p{

max-width:700px;

margin:auto;

line-height:1.8;

color:#666;

}

.gallery{

padding:0 8% 100px;

display:grid;

grid-template-columns:repeat(3,1fr);

gap:30px;

}

.card{

background:white;

border-radius:18px;

overflow:hidden;

box-shadow:0 8px 25px rgba(0,0,0,.08);

transition:.3s;

cursor:pointer;

}

.card:hover{

transform:translateY(-10px);

}

.card img{

width:100%;

height:260px;

object-fit:cover;

}

.content{

padding:20px;

}

.content span{

display:inline-block;

background:#ff6b00;

color:white;

padding:6px 12px;

border-radius:20px;

font-size:14px;

margin-bottom:15px;

}

.content h3{

color:#081A38;

}

@media(max-width:992px){

.gallery{

grid-template-columns:1fr;

}

.overlay h1{

font-size:36px;

}

}

</style>