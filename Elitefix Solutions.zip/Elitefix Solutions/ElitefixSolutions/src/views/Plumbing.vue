<template>

<Navbar/>

<!-- Hero -->

<section class="hero">

<div class="overlay">

<h4>PLUMBING SERVICES</h4>

<h1>
Professional Plumbing
Services in Dubai
</h1>

<p>

From leaking pipes to complete plumbing
installations, EliteFix Solutions provides
fast, reliable, and affordable plumbing
services across Dubai.

</p>

</div>

</section>

<!-- About -->

<section class="service">

<div class="image">

</div>

<div class="content">

<h5>ABOUT OUR SERVICE</h5>

<h2>

Reliable Plumbing Solutions

</h2>

<p>

Our licensed plumbers handle residential
and commercial plumbing projects with
precision and professionalism.

</p>

<div class="list">

<div>✔ Pipe Installation</div>

<div>✔ Leak Detection</div>

<div>✔ Drain Cleaning</div>

<div>✔ Bathroom Plumbing</div>

<div>✔ Kitchen Plumbing</div>

<div>✔ Water Tank Maintenance</div>

</div>

</div>

</section>

<!-- Benefits -->

<section class="benefits">

<h2>

Why Choose Our Plumbing Service?

</h2>

<div class="cards">

<div class="card">

🚰

<h3>Leak Detection</h3>

<p>

Advanced tools to quickly locate and
repair hidden leaks.

</p>

</div>

<div class="card">

🔧

<h3>Professional Repairs</h3>

<p>

Quality plumbing repairs using
premium materials.

</p>

</div>

<div class="card">

💧

<h3>24/7 Emergency</h3>

<p>

Fast emergency plumbing support
when you need it most.

</p>

</div>

</div>

</section>

<!-- Working Process -->

<section class="process">

<h2>

How We Work

</h2>

<div class="steps">

<div>

1️⃣ Contact Us

</div>

<div>

2️⃣ Inspection

</div>

<div>

3️⃣ Repair / Installation

</div>

<div>

4️⃣ Final Testing

</div>

</div>

</section>

<!-- Gallery -->

<section class="gallery">

<h2>

Recent Plumbing Projects

</h2>

<div class="grid">


</div>

</section>

<!-- FAQ -->

<section class="faq">

<h2>

Frequently Asked Questions

</h2>

<div class="question">

<h3>

Do you provide emergency plumbing?

</h3>

<p>

Yes. We offer emergency plumbing
services throughout Dubai.

</p>

</div>

<div class="question">

<h3>

Can you fix water leakage?

</h3>

<p>

Yes. We repair all types of leaks,
including hidden pipe leaks.

</p>

</div>

<div class="question">

<h3>

Do you install new bathroom fittings?

</h3>

<p>

Yes. We install sinks, faucets,
showers, toilets, and complete
bathroom plumbing systems.

</p>

</div>

</section>

<RequestQuoteSection/>

<Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

.hero{

height:55vh;
background:url('/images/services/plumbing/banner.jpg');
background-size:cover;
background-position:center;

}

.overlay{

height:100%;
background:rgba(8,26,56,.75);

display:flex;
justify-content:center;
align-items:center;
flex-direction:column;

text-align:center;
color:white;

padding:20px;

}

.overlay h4{

color:#ff6b00;

}

.overlay h1{

font-size:48px;
margin:20px 0;

}

.overlay p{

max-width:700px;
line-height:1.8;

}

.service{

padding:100px 8%;
display:grid;
grid-template-columns:1fr 1fr;
gap:60px;
align-items:center;

}

.service img{

width:100%;
border-radius:20px;

}

.content h5{

color:#ff6b00;

}

.content h2{

font-size:42px;
margin:20px 0;
color:#081A38;

}

.content p{

line-height:1.9;
color:#666;

}

.list{

margin-top:30px;

display:grid;
grid-template-columns:1fr 1fr;

gap:20px;

font-weight:600;

}

.benefits{

padding:100px 8%;

background:#f8f9fb;

text-align:center;

}

.cards{

display:grid;

grid-template-columns:repeat(3,1fr);

gap:30px;

margin-top:40px;

}

.card{

background:white;

padding:40px;

border-radius:18px;

box-shadow:0 10px 25px rgba(0,0,0,.08);

}

.card h3{

margin:20px 0;

color:#081A38;

}

.process{

padding:100px 8%;

text-align:center;

}

.steps{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

margin-top:40px;

}

.steps div{

padding:30px;

background:#081A38;

color:white;

border-radius:15px;

font-weight:bold;

}

.gallery{

padding:100px 8%;

}

.gallery h2{

text-align:center;

margin-bottom:40px;

}

.grid{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

}

.grid img{

width:100%;
height:250px;

object-fit:cover;

border-radius:15px;

}

.faq{

padding:100px 8%;

}

.question{

background:#f7f8fa;

padding:25px;

border-radius:12px;

margin-bottom:20px;

}

@media(max-width:992px){

.service{

grid-template-columns:1fr;

}

.cards{

grid-template-columns:1fr;

}

.steps{

grid-template-columns:1fr;

}

.grid{

grid-template-columns:1fr;

}

.overlay h1{

font-size:34px;

}

.list{

grid-template-columns:1fr;

}

}

</style>