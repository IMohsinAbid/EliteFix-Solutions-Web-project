<template>

  <Navbar />

  <!-- Hero -->

  <section class="hero">

    <div class="overlay">

      <h4>CONTACT US</h4>

      <h1>Let's Discuss Your Project</h1>

      <p>
        Need professional maintenance services?
        Contact EliteFix Solutions today for a free consultation.
      </p>

    </div>

  </section>

  <!-- Contact Section -->

  <section class="contact">

    <!-- Left -->

    <div class="info">

      <h2>Get In Touch</h2>

      <p>

        We're always ready to help you with your
        maintenance and renovation needs.

      </p>

      <div class="item">

        <h4>📍 Office Address</h4>

        <p>Dubai, United Arab Emirates</p>

      </div>

      <div class="item">

        <h4>📞 Phone</h4>

        <p>+971 50 123 4567</p>

      </div>

      <div class="item">

        <h4>✉ Email</h4>

        <p>info@elitefixsolutions.com</p>

      </div>

      <div class="item">

        <h4>🕒 Working Hours</h4>

        <p>Monday - Saturday (8 AM - 8 PM)</p>

      </div>

    </div>

    <!-- Right -->

    <div class="form">

      <h2>Send Message</h2>

      <form>

        <input
        type="text"
        placeholder="Full Name">

        <input
        type="email"
        placeholder="Email Address">

        <input
        type="tel"
        placeholder="Phone Number">

        <select>

          <option>Select Service</option>

          <option>AC Maintenance</option>

          <option>Plumbing</option>

          <option>Electrical</option>

          <option>Home Maintenance</option>

          <option>Soil Work</option>

          <option>Media Wall</option>

        </select>

        <textarea
        rows="6"
        placeholder="Your Message"></textarea>

        <button>

          Send Message

        </button>

      </form>

    </div>

  </section>

  <!-- Google Map -->

  <section class="map">

    <h2>Find Us</h2>

    <iframe
      src="https://www.google.com/maps?q=Dubai&output=embed"
      loading="lazy">
    </iframe>

  </section>

  <RequestQuoteSection />

  <Footer />

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

.hero{

height:55vh;
background:url('/images/contact/contact-banner.jpg') center/cover no-repeat;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

text-align:center;

color:white;

padding:20px;

}

.overlay h4{

color:#ff6b00;

letter-spacing:2px;

}

.overlay h1{

font-size:50px;

margin:20px 0;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.contact{

padding:100px 8%;

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

}

.info h2,
.form h2{

font-size:40px;

color:#081A38;

margin-bottom:25px;

}

.info p{

line-height:1.8;

color:#666;

margin-bottom:20px;

}

.item{

margin-bottom:25px;

}

.item h4{

color:#ff6b00;

margin-bottom:8px;

}

form{

display:flex;

flex-direction:column;

gap:18px;

}

input,
select,
textarea{

padding:15px;

border:1px solid #ddd;

border-radius:10px;

font-size:16px;

outline:none;

}

input:focus,
select:focus,
textarea:focus{

border-color:#ff6b00;

}

button{

background:#ff6b00;

color:white;

padding:15px;

border:none;

border-radius:10px;

font-size:17px;

font-weight:600;

cursor:pointer;

transition:.3s;

}

button:hover{

background:#e55d00;

}

.map{

padding:0 8% 100px;

}

.map h2{

text-align:center;

font-size:40px;

color:#081A38;

margin-bottom:30px;

}

iframe{

width:100%;

height:450px;

border:none;

border-radius:20px;

}

@media(max-width:992px){

.contact{

grid-template-columns:1fr;

}

.overlay h1{

font-size:36px;

}

}

</style>