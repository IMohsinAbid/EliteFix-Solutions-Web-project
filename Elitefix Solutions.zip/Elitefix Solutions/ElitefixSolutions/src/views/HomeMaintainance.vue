<template>

  <Navbar/>

  <!-- Hero Section -->
  <section class="hero">

    <div class="overlay">

      <h4>HOME MAINTENANCE</h4>

      <h1>
        Complete Home Maintenance
        Services in Dubai
      </h1>

      <p>
        Keep your property in excellent condition with our
        professional home maintenance solutions for residential
        and commercial buildings.
      </p>

    </div>

  </section>

  <!-- About Service -->

  <section class="service">

    <div class="image">

     

    </div>

    <div class="content">

      <h5>ABOUT OUR SERVICE</h5>

      <h2>

        Reliable Property Maintenance

      </h2>

      <p>

        EliteFix Solutions provides complete home maintenance
        services to ensure your property stays safe,
        functional, and well-maintained throughout the year.

      </p>

      <div class="list">

        <div>✔ General Home Repairs</div>

        <div>✔ Door & Lock Repairs</div>

        <div>✔ Ceiling & Wall Repairs</div>

        <div>✔ Painting & Touch-Ups</div>

        <div>✔ Tile & Flooring Repairs</div>

        <div>✔ Preventive Maintenance</div>

      </div>

    </div>

  </section>

  <!-- Benefits -->

  <section class="benefits">

    <h2>

      Why Choose Our Home Maintenance?

    </h2>

    <div class="cards">

      <div class="card">

        🏠

        <h3>Complete Solutions</h3>

        <p>

          From minor repairs to complete
          maintenance, we handle it all.

        </p>

      </div>

      <div class="card">

        🔧

        <h3>Experienced Team</h3>

        <p>

          Skilled technicians with years
          of practical experience.

        </p>

      </div>

      <div class="card">

        ⭐

        <h3>Quality Workmanship</h3>

        <p>

          High-quality repairs using
          premium materials.

        </p>

      </div>

    </div>

  </section>

  <!-- Working Process -->

  <section class="process">

    <h2>

      Our Working Process

    </h2>

    <div class="steps">

      <div>1️⃣ Request Service</div>

      <div>2️⃣ Site Inspection</div>

      <div>3️⃣ Maintenance Work</div>

      <div>4️⃣ Final Quality Check</div>

    </div>

  </section>

  <!-- Gallery -->

  <section class="gallery">

    <h2>

      Our Recent Projects

    </h2>

    <div class="grid">


    </div>

  </section>

  <!-- FAQ -->

  <section class="faq">

    <h2>

      Frequently Asked Questions

    </h2>

    <div class="question">

      <h3>

        What does home maintenance include?

      </h3>

      <p>

        General repairs, painting,
        carpentry, door repairs,
        wall maintenance,
        and preventive maintenance.

      </p>

    </div>

    <div class="question">

      <h3>

        Do you offer annual maintenance?

      </h3>

      <p>

        Yes. We provide annual
        maintenance packages for homes
        and commercial properties.

      </p>

    </div>

    <div class="question">

      <h3>

        Can I schedule regular visits?

      </h3>

      <p>

        Absolutely. We offer weekly,
        monthly, and yearly maintenance
        plans.

      </p>

    </div>

  </section>

  <RequestQuoteSection/>

  <Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

.hero{
height:55vh;
background:url('/images/services/home-maintenance/banner.jpg') center/cover no-repeat;
}

.overlay{
height:100%;
background:rgba(8,26,56,.75);
display:flex;
flex-direction:column;
justify-content:center;
align-items:center;
text-align:center;
padding:20px;
color:white;
}

.overlay h4{
color:#ff6b00;
letter-spacing:2px;
}

.overlay h1{
font-size:48px;
margin:20px 0;
}

.overlay p{
max-width:700px;
line-height:1.8;
}

.service{
padding:100px 8%;
display:grid;
grid-template-columns:1fr 1fr;
gap:60px;
align-items:center;
}

.service img{
width:100%;
border-radius:18px;
}

.content h5{
color:#ff6b00;
}

.content h2{
font-size:42px;
margin:20px 0;
color:#081A38;
}

.content p{
line-height:1.8;
color:#666;
}

.list{
margin-top:30px;
display:grid;
grid-template-columns:repeat(2,1fr);
gap:18px;
font-weight:600;
}

.benefits{
padding:100px 8%;
background:#f8f9fb;
text-align:center;
}

.cards{
display:grid;
grid-template-columns:repeat(3,1fr);
gap:30px;
margin-top:40px;
}

.card{
background:white;
padding:40px;
border-radius:18px;
box-shadow:0 10px 25px rgba(0,0,0,.08);
}

.card h3{
margin:20px 0;
color:#081A38;
}

.process{
padding:100px 8%;
text-align:center;
}

.steps{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
margin-top:40px;
}

.steps div{
background:#081A38;
color:white;
padding:30px;
border-radius:15px;
font-weight:bold;
}

.gallery{
padding:100px 8%;
}

.gallery h2{
text-align:center;
margin-bottom:40px;
}

.grid{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
}

.grid img{
width:100%;
height:250px;
object-fit:cover;
border-radius:15px;
}

.faq{
padding:100px 8%;
}

.question{
background:#f7f8fa;
padding:25px;
margin-bottom:20px;
border-radius:12px;
}

@media(max-width:992px){

.service{
grid-template-columns:1fr;
}

.cards{
grid-template-columns:1fr;
}

.steps{
grid-template-columns:1fr;
}

.grid{
grid-template-columns:1fr;
}

.overlay h1{
font-size:34px;
}

.list{
grid-template-columns:1fr;
}

}

</style>