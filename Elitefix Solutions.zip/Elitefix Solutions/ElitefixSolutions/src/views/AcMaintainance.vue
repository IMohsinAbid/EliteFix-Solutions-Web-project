<template>

<Navbar/>

<!-- Hero -->

<section class="hero">

<div class="overlay">

<h4>AC MAINTENANCE</h4>

<h1>
Professional AC Maintenance &
Repair Services
</h1>

<p>

Keep your home cool with our
expert AC maintenance,
installation and repair services.

</p>

</div>

</section>

<!-- About Service -->

<section class="service">

<div class="image">


</div>

<div class="content">

<h5>ABOUT SERVICE</h5>

<h2>
Complete Air Conditioning
Solutions
</h2>

<p>

Our experienced technicians provide
preventive maintenance, emergency repairs,
gas refilling, duct cleaning,
and complete AC installations.

</p>

<div class="list">

<div>✔ AC Installation</div>

<div>✔ AC Repair</div>

<div>✔ Gas Refilling</div>

<div>✔ Duct Cleaning</div>

<div>✔ Filter Replacement</div>

<div>✔ Annual Maintenance</div>

</div>

</div>

</section>

<!-- Benefits -->

<section class="benefits">

<h2>
Why Choose Our AC Service?
</h2>

<div class="cards">

<div class="card">

❄️

<h3>Energy Efficient</h3>

<p>
Improve cooling performance.
</p>

</div>

<div class="card">

⚡

<h3>Fast Repairs</h3>

<p>
Same-day emergency service.
</p>

</div>

<div class="card">

🛠

<h3>Certified Experts</h3>

<p>
Experienced AC technicians.
</p>

</div>

</div>

</section>

<!-- Working Process -->

<section class="process">

<h2>
How We Work
</h2>

<div class="steps">

<div>1️⃣ Request Service</div>

<div>2️⃣ Inspection</div>

<div>3️⃣ Repair</div>

<div>4️⃣ Testing</div>

</div>

</section>

<!-- Gallery -->

<section class="gallery">

<h2>
Recent AC Projects
</h2>

<div class="grid">


</div>

</section>

<!-- FAQ -->

<section class="faq">

<h2>

Frequently Asked Questions

</h2>

<div class="question">

<h3>
How often should AC be serviced?

</h3>

<p>

Every 6 months is recommended.

</p>

</div>

<div class="question">

<h3>

Do you provide emergency repairs?

</h3>

<p>

Yes, across Dubai.

</p>

</div>

</section>

<RequestQuoteSection/>

<Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

.hero{

height:55vh;

background:url('/images/services/ac/banner.jpg');

background-size:cover;

background-position:center;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

text-align:center;

color:white;

padding:20px;

}

.overlay h4{

color:#ff6b00;

}

.overlay h1{

font-size:48px;

margin:20px 0;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.service{

padding:100px 8%;

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

align-items:center;

}

.service img{

width:100%;

border-radius:20px;

}

.content h5{

color:#ff6b00;

}

.content h2{

font-size:42px;

margin:20px 0;

color:#081A38;

}

.content p{

line-height:1.9;

color:#666;

}

.list{

margin-top:30px;

display:grid;

grid-template-columns:1fr 1fr;

gap:20px;

font-weight:600;

}

.benefits{

padding:100px 8%;

background:#f7f8fa;

text-align:center;

}

.cards{

margin-top:50px;

display:grid;

grid-template-columns:repeat(3,1fr);

gap:30px;

}

.card{

background:white;

padding:40px;

border-radius:18px;

box-shadow:0 8px 20px rgba(0,0,0,.08);

}

.card h3{

margin:20px 0;

color:#081A38;

}

.process{

padding:100px 8%;

text-align:center;

}

.steps{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:25px;

margin-top:40px;

}

.steps div{

padding:30px;

background:#081A38;

color:white;

border-radius:15px;

font-weight:bold;

}

.gallery{

padding:100px 8%;

}

.gallery h2{

text-align:center;

margin-bottom:40px;

}

.grid{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

}

.grid img{

width:100%;

height:260px;

object-fit:cover;

border-radius:15px;

}

.faq{

padding:100px 8%;

}

.question{

background:#f7f8fa;

padding:25px;

margin-bottom:20px;

border-radius:12px;

}

@media(max-width:992px){

.service{

grid-template-columns:1fr;

}

.cards{

grid-template-columns:1fr;

}

.steps{

grid-template-columns:1fr;

}

.grid{

grid-template-columns:1fr;

}

.overlay h1{

font-size:34px;

}

.list{

grid-template-columns:1fr;

}

}

</style>