<template>

  <Navbar/>

  <!-- Hero -->
  <section class="hero">
    <div class="overlay">
      <h4>ELECTRICAL SERVICES</h4>

      <h1>
        Professional Electrical
        Services in Dubai
      </h1>

      <p>
        Safe, reliable and affordable electrical
        installation, maintenance and repair
        services for residential and commercial
        properties.
      </p>
    </div>
  </section>

  <!-- About -->

  <section class="service">

    <div class="image">

     

    </div>

    <div class="content">

      <h5>ABOUT OUR SERVICE</h5>

      <h2>
        Complete Electrical Solutions
      </h2>

      <p>

        EliteFix Solutions offers professional
        electrical services including wiring,
        switch installation, lighting,
        troubleshooting and complete electrical
        maintenance across Dubai.

      </p>

      <div class="list">

        <div>✔ Electrical Wiring</div>

        <div>✔ Lighting Installation</div>

        <div>✔ Power Socket Installation</div>

        <div>✔ Switch Replacement</div>

        <div>✔ Circuit Breaker Repair</div>

        <div>✔ Electrical Maintenance</div>

      </div>

    </div>

  </section>

  <!-- Benefits -->

  <section class="benefits">

    <h2>
      Why Choose Our Electrical Service?
    </h2>

    <div class="cards">

      <div class="card">

        ⚡

        <h3>Certified Electricians</h3>

        <p>

          Experienced professionals
          ensuring safe electrical work.

        </p>

      </div>

      <div class="card">

        🔌

        <h3>Modern Equipment</h3>

        <p>

          We use professional tools
          for accurate installation
          and repairs.

        </p>

      </div>

      <div class="card">

        🛡

        <h3>Safety Guaranteed</h3>

        <p>

          Every electrical project
          follows Dubai safety
          standards.

        </p>

      </div>

    </div>

  </section>

  <!-- Process -->

  <section class="process">

    <h2>Our Working Process</h2>

    <div class="steps">

      <div>1️⃣ Book Service</div>

      <div>2️⃣ Site Inspection</div>

      <div>3️⃣ Installation / Repair</div>

      <div>4️⃣ Final Testing</div>

    </div>

  </section>

  <!-- Gallery -->

  <section class="gallery">

    <h2>Recent Electrical Projects</h2>

    <div class="grid">



    </div>

  </section>

  <!-- FAQ -->

  <section class="faq">

    <h2>
      Frequently Asked Questions
    </h2>

    <div class="question">

      <h3>
        Do you install new electrical wiring?
      </h3>

      <p>

        Yes. We provide complete wiring
        installation for homes and offices.

      </p>

    </div>

    <div class="question">

      <h3>
        Can you repair electrical faults?
      </h3>

      <p>

        Yes. Our technicians quickly
        diagnose and repair electrical
        issues.

      </p>

    </div>

    <div class="question">

      <h3>
        Do you install LED lights?
      </h3>

      <p>

        Yes. We install indoor,
        outdoor and decorative
        LED lighting.

      </p>

    </div>

  </section>

  <RequestQuoteSection/>

  <Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import RequestQuoteSection from "@/components/RequestQuoteSection.vue"

</script>

<style scoped>

/* Hero */

.hero{

height:55vh;
background:url('/images/services/electrical/banner.jpg') center/cover no-repeat;

}

.overlay{

height:100%;
background:rgba(8,26,56,.75);

display:flex;
flex-direction:column;
justify-content:center;
align-items:center;

text-align:center;
color:white;
padding:20px;

}

.overlay h4{

color:#ff6b00;

letter-spacing:2px;

}

.overlay h1{

font-size:48px;

margin:20px 0;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

/* Service */

.service{

padding:100px 8%;

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

align-items:center;

}

.service img{

width:100%;

border-radius:18px;

}

.content h5{

color:#ff6b00;

}

.content h2{

font-size:42px;

margin:20px 0;

color:#081A38;

}

.content p{

line-height:1.9;

color:#666;

}

.list{

margin-top:30px;

display:grid;

grid-template-columns:repeat(2,1fr);

gap:18px;

font-weight:600;

}

/* Benefits */

.benefits{

padding:100px 8%;

background:#f7f8fa;

text-align:center;

}

.cards{

margin-top:45px;

display:grid;

grid-template-columns:repeat(3,1fr);

gap:30px;

}

.card{

background:white;

padding:40px;

border-radius:18px;

box-shadow:0 10px 30px rgba(0,0,0,.08);

transition:.3s;

}

.card:hover{

transform:translateY(-8px);

}

.card h3{

margin:20px 0;

color:#081A38;

}

/* Process */

.process{

padding:100px 8%;

text-align:center;

}

.steps{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

margin-top:40px;

}

.steps div{

background:#081A38;

color:white;

padding:30px;

border-radius:15px;

font-weight:bold;

}

/* Gallery */

.gallery{

padding:100px 8%;

}

.gallery h2{

text-align:center;

margin-bottom:40px;

}

.grid{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

}

.grid img{

width:100%;

height:240px;

object-fit:cover;

border-radius:15px;

}

/* FAQ */

.faq{

padding:100px 8%;

}

.question{

background:#f8f9fb;

padding:25px;

margin-bottom:20px;

border-radius:12px;

}

/* Responsive */

@media(max-width:992px){

.service{

grid-template-columns:1fr;

}

.cards{

grid-template-columns:1fr;

}

.steps{

grid-template-columns:1fr;

}

.grid{

grid-template-columns:1fr;

}

.overlay h1{

font-size:34px;

}

.list{

grid-template-columns:1fr;

}

}

</style>