<template>
  <section class="hero">

    <!-- Left Content -->
    <div class="hero-content">

      <span class="badge">
        ⭐ Trusted Technical Services in Dubai
      </span>

      <h1>
        Professional Home <br>
        Maintenance & Technical <br>
        Services in <span>Dubai</span>
      </h1>

      <p>
        EliteFix Solutions provides reliable AC maintenance, plumbing,
        electrical, home maintenance, soil work, and media wall installation
        services across Dubai.
      </p>

      <div class="hero-buttons">

        <RouterLink to="/request-quote" class="btn-primary">
          Request a Quote
        </RouterLink>

        <a href="tel:+971501234567" class="btn-secondary">
          📞 Call Now
        </a>

      </div>

      <div class="features">

        <div class="feature">
          <div class="icon">👨‍🔧</div>
          <div>
            <h4>Skilled Technicians</h4>
            <small>Certified Professionals</small>
          </div>
        </div>

        <div class="feature">
          <div class="icon">⏰</div>
          <div>
            <h4>On-Time Service</h4>
            <small>Always Punctual</small>
          </div>
        </div>

        <div class="feature">
          <div class="icon">🛡️</div>
          <div>
            <h4>100% Satisfaction</h4>
            <small>Quality Guaranteed</small>
          </div>
        </div>

      </div>

    </div>

    <!-- Right Image -->

    <div class="hero-image">

      <img
        src="@/assets/images/hero-technician.png"
        alt="EliteFix Technician">

    </div>

  </section>
</template>

<script setup>
</script>

<style scoped>

.hero{

display:flex;
align-items:center;
justify-content:space-between;

padding:80px 8%;

background:linear-gradient(to right,#ffffff,#eef5ff);

min-height:88vh;

}

.hero-content{

width:50%;

}

.badge{

display:inline-block;

background:#ffe9d7;

color:#ff6b00;

padding:10px 18px;

border-radius:30px;

font-weight:600;

margin-bottom:20px;

}

.hero h1{

font-size:58px;

line-height:1.2;

color:#081A38;

margin-bottom:20px;

}

.hero h1 span{

color:#ff6b00;

}

.hero p{

font-size:18px;

color:#666;

line-height:1.8;

margin-bottom:35px;

}

.hero-buttons{

display:flex;

gap:20px;

margin-bottom:45px;

}

.btn-primary{

background:#ff6b00;

color:white;

padding:16px 30px;

border-radius:10px;

text-decoration:none;

font-weight:bold;

}

.btn-secondary{

padding:16px 30px;

border:2px solid #081A38;

border-radius:10px;

text-decoration:none;

font-weight:bold;

color:#081A38;

}

.features{

display:flex;

gap:30px;

flex-wrap:wrap;

}

.feature{

display:flex;

align-items:center;

gap:15px;

}

.icon{

width:55px;

height:55px;

background:#081A38;

color:white;

display:flex;

align-items:center;

justify-content:center;

border-radius:50%;

font-size:24px;

}

.feature h4{

color:#081A38;

}

.feature small{

color:#777;

}

.hero-image{

width:45%;

display:flex;

justify-content:center;

}

.hero-image img{

width:100%;

max-width:650px;

}

@media(max-width:992px){

.hero{

flex-direction:column;

text-align:center;

padding:60px 25px;

}

.hero-content{

width:100%;

}

.hero-image{

width:100%;

margin-top:40px;

}

.hero h1{

font-size:38px;

}

.features{

justify-content:center;

}

.hero-buttons{

justify-content:center;

flex-wrap:wrap;

}

}

</style>