<template>
  <div class="service-card">

    <img :src="image" :alt="title">

    <div class="content">

      <div class="icon">
        {{ icon }}
      </div>

      <h3>{{ title }}</h3>

      <p>{{ description }}</p>

      <button
        class="learn-btn"
        @click="viewService"
      >
        Learn More →
      </button>

    </div>

  </div>
</template>

<script setup>

const props = defineProps({

  title:String,
  icon:String,
  image:String,
  description:String,
  link:String

})

const emit = defineEmits(["view-service"])

const viewService = () => {

  emit("view-service", props.link)

}

</script>