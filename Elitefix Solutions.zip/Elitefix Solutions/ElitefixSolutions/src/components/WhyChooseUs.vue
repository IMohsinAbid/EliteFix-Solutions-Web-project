<template>
  <section class="why-us">

    <div class="heading">

      <span>WHY CHOOSE US</span>

      <h2>
        Why Dubai Trusts
        <span>EliteFix Solutions</span>
      </h2>

      <p>
        We combine skilled professionals, quality workmanship,
        and quick response times to deliver dependable technical
        services across Dubai.
      </p>

    </div>

    <div class="features">

      <div
        class="feature-card"
        v-for="feature in features"
        :key="feature.title"
      >

        <div class="feature-icon">
          {{ feature.icon }}
        </div>

        <h3>{{ feature.title }}</h3>

        <p>{{ feature.description }}</p>

      </div>

    </div>

  </section>
</template>

<script setup>

const features = [

{
icon:"👨‍🔧",
title:"Certified Technicians",
description:"Experienced professionals trained to deliver safe and reliable technical services."
},

{
icon:"⚡",
title:"Fast Response",
description:"Quick response times with same-day service available across Dubai."
},

{
icon:"💰",
title:"Affordable Pricing",
description:"Transparent pricing with no hidden costs and free quotations."
},

{
icon:"🛡️",
title:"Quality Guarantee",
description:"We use quality materials and ensure every project meets high standards."
},

{
icon:"⏰",
title:"On-Time Service",
description:"We respect your schedule by arriving on time and completing work efficiently."
},

{
icon:"😊",
title:"Customer Satisfaction",
description:"Our commitment is to exceed customer expectations with every project."
}

]

</script>

<style scoped>

.why-us{

padding:90px 8%;

background:white;

}

.heading{

text-align:center;

max-width:700px;

margin:auto;

margin-bottom:60px;

}

.heading span{

color:#ff6b00;

font-weight:700;

letter-spacing:2px;

}

.heading h2{

font-size:44px;

margin:15px 0;

color:#081A38;

}

.heading h2 span{

color:#ff6b00;

}

.heading p{

color:#666;

line-height:1.8;

}

.features{

display:grid;

grid-template-columns:repeat(3,1fr);

gap:35px;

}

.feature-card{

padding:40px 30px;

background:#fff;

border-radius:18px;

box-shadow:0 8px 25px rgba(0,0,0,.08);

transition:.35s;

text-align:center;

border-top:5px solid transparent;

}

.feature-card:hover{

transform:translateY(-10px);

border-top:5px solid #ff6b00;

}

.feature-icon{

width:80px;

height:80px;

margin:auto;

margin-bottom:25px;

border-radius:50%;

background:#081A38;

display:flex;

align-items:center;

justify-content:center;

font-size:34px;

color:white;

}

.feature-card h3{

font-size:24px;

color:#081A38;

margin-bottom:15px;

}

.feature-card p{

color:#666;

line-height:1.7;

}

@media(max-width:992px){

.features{

grid-template-columns:1fr;

}

.heading h2{

font-size:34px;

}

}
</style>