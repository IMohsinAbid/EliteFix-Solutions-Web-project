<template>
  <section class="stats">

    <div class="overlay">

      <div class="heading">
        <span>OUR ACHIEVEMENTS</span>
        <h2>Trusted Across Dubai</h2>
        <p>
          Delivering quality home maintenance and technical services with
          professionalism and customer satisfaction.
        </p>
      </div>

      <div class="stats-grid">

        <div class="stat-card">

          <h1>500+</h1>
          <h4>Projects Completed</h4>

        </div>

        <div class="stat-card">

          <h1>350+</h1>
          <h4>Happy Clients</h4>

        </div>

        <div class="stat-card">

          <h1>15+</h1>
          <h4>Expert Technicians</h4>

        </div>

        <div class="stat-card">

          <h1>8+</h1>
          <h4>Years Experience</h4>

        </div>

      </div>

    </div>

  </section>
</template>

<script setup>
</script>

<style scoped>

.stats{

background:url('/images/stats-bg.jpg') center center/cover no-repeat;

position:relative;

padding:100px 8%;

}

.overlay{

background:rgba(8,26,56,.90);

padding:80px 50px;

border-radius:20px;

}

.heading{

text-align:center;

color:white;

margin-bottom:60px;

}

.heading span{

color:#ff6b00;

font-weight:bold;

letter-spacing:2px;

}

.heading h2{

font-size:42px;

margin:15px 0;

}

.heading p{

max-width:700px;

margin:auto;

line-height:1.8;

color:#ddd;

}

.stats-grid{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:30px;

}

.stat-card{

background:white;

padding:40px 20px;

border-radius:18px;

text-align:center;

transition:.3s;

}

.stat-card:hover{

transform:translateY(-10px);

}

.stat-card h1{

font-size:52px;

color:#ff6b00;

margin-bottom:10px;

}

.stat-card h4{

color:#081A38;

font-size:20px;

}

@media(max-width:992px){

.stats-grid{

grid-template-columns:repeat(2,1fr);

}

.heading h2{

font-size:34px;

}

}

@media(max-width:600px){

.stats-grid{

grid-template-columns:1fr;

}

.overlay{

padding:50px 25px;

}

}

</style>