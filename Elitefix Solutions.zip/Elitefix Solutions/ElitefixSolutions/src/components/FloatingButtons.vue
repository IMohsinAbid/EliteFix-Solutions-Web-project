<template>
  <div
    class="floating-buttons"
    :style="{ left: x + 'px', top: y + 'px' }"
    @mousedown="startDrag"
    @touchstart="startDrag"
  >
    <!-- WhatsApp -->
    <a
      href="https://wa.me/971501234567"
      target="_blank"
      class="btn whatsapp"
      title="Chat on WhatsApp"
    >
      <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Phone -->
    <a
      href="tel:+971501234567"
      class="btn phone"
      title="Call Now"
    >
      <i class="fas fa-phone"></i>
    </a>
  </div>
</template>

<script setup>
import { ref } from "vue"

const x = ref(window.innerWidth - 90)
const y = ref(window.innerHeight - 180)

let dragging = false
let offsetX = 0
let offsetY = 0

const startDrag = (event) => {
  dragging = true

  const touch = event.touches ? event.touches[0] : event

  offsetX = touch.clientX - x.value
  offsetY = touch.clientY - y.value

  window.addEventListener("mousemove", move)
  window.addEventListener("mouseup", stop)

  window.addEventListener("touchmove", move)
  window.addEventListener("touchend", stop)
}

const move = (event) => {
  if (!dragging) return

  const touch = event.touches ? event.touches[0] : event

  x.value = touch.clientX - offsetX
  y.value = touch.clientY - offsetY
}

const stop = () => {
  dragging = false

  window.removeEventListener("mousemove", move)
  window.removeEventListener("mouseup", stop)

  window.removeEventListener("touchmove", move)
  window.removeEventListener("touchend", stop)
}
</script>

<style scoped>

.floating-buttons{
position:fixed;
z-index:9999;

display:flex;
flex-direction:column;
gap:15px;

cursor:grab;
}

.btn{

width:60px;
height:60px;

border-radius:50%;

display:flex;
align-items:center;
justify-content:center;

font-size:28px;

color:white;
text-decoration:none;

box-shadow:0 8px 25px rgba(0,0,0,.25);

transition:.3s;
}

.btn:hover{
transform:scale(1.1);
}

.whatsapp{
background:#25D366;
}

.phone{
background:#ff6b00;
}

</style>