<template>
  <header>

    <!-- Top Bar -->
    <div class="top-bar">
      <div class="top-left">
        <span>📍 Serving All Across Dubai</span>
      </div>

      <div class="top-right">
        <span>📞 +971 50 123 4567</span>
        <span>🕒 Mon - Sat | 8:00 AM - 8:00 PM</span>
      </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">

      <!-- Logo -->
      <RouterLink to="/" class="logo">

        <div class="logo-icon">
          🏠
        </div>

        <div class="logo-text">
          <h2>EliteFix</h2>
          <h4>Solutions</h4>
          <small>Where Quality Meets Reliability</small>
        </div>

      </RouterLink>

      <!-- Navigation Links -->
      <ul class="nav-links">

        <li><RouterLink to="/">Home</RouterLink></li>

        <li><RouterLink to="/about">About</RouterLink></li>

        <li class="dropdown">

          <RouterLink to="/services">
            Services ▼
          </RouterLink>

          <ul class="dropdown-menu">

            <li><RouterLink to="/services/ac-maintenance">AC Maintenance</RouterLink></li>

            <li><RouterLink to="/services/plumbing">Plumbing</RouterLink></li>

            <li><RouterLink to="/services/electrical">Electrical</RouterLink></li>

            <li><RouterLink to="/services/home-maintenance">Home Maintenance</RouterLink></li>

            <li><RouterLink to="/services/soil-work">Soil Work</RouterLink></li>

            <li><RouterLink to="/services/media-wall">Media Wall</RouterLink></li>

          </ul>

        </li>

        <li><RouterLink to="/gallery">Gallery</RouterLink></li>

        <li><RouterLink to="/contact">Contact</RouterLink></li>

      </ul>

      <!-- CTA -->
      <RouterLink to="/request-quote" class="quote-btn">
        Request a Quote
      </RouterLink>

    </nav>

  </header>
</template>

<script setup>
</script>

<style scoped>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial, Helvetica, sans-serif;
}

/* Top Bar */

.top-bar{

background:#081A38;
color:#fff;

display:flex;
justify-content:space-between;
align-items:center;

padding:10px 8%;

font-size:14px;

}

.top-right{

display:flex;
gap:30px;

}

/* Navbar */

.navbar{

display:flex;
justify-content:space-between;
align-items:center;

padding:18px 8%;

background:#fff;

position:sticky;
top:0;
z-index:1000;

box-shadow:0 2px 15px rgba(0,0,0,.08);

}

/* Logo */

.logo{

display:flex;
align-items:center;

gap:12px;

text-decoration:none;

}

.logo-icon{

width:60px;
height:60px;

background:#ff6b00;

border-radius:15px;

display:flex;
align-items:center;
justify-content:center;

font-size:28px;

color:#fff;

}

.logo-text h2{

font-size:30px;
color:#081A38;

}

.logo-text h4{

color:#ff6b00;
margin-top:-5px;

}

.logo-text small{

display:block;

color:#777;

font-size:11px;

margin-top:4px;

}

/* Links */

.nav-links{

display:flex;
gap:35px;

list-style:none;

}

.nav-links a{

text-decoration:none;

color:#081A38;

font-weight:600;

transition:.3s;

}

.nav-links a:hover{

color:#ff6b00;

}

/* Dropdown */

.dropdown{

position:relative;

}

.dropdown-menu{

position:absolute;

top:45px;
left:0;

background:#fff;

width:260px;

display:none;

border-radius:10px;

box-shadow:0 10px 25px rgba(0,0,0,.12);

overflow:hidden;

}

.dropdown:hover .dropdown-menu{

display:block;

}

.dropdown-menu li{

list-style:none;

}

.dropdown-menu a{

display:block;

padding:15px 20px;

}

.dropdown-menu a:hover{

background:#f8f8f8;

}

/* CTA */

.quote-btn{

background:#ff6b00;

padding:14px 28px;

color:#fff;

text-decoration:none;

font-weight:600;

border-radius:10px;

transition:.3s;

}

.quote-btn:hover{

background:#e65f00;

}

/* Mobile */

@media(max-width:992px){

.top-bar{

display:none;

}

.nav-links{

display:none;

}

.quote-btn{

display:none;

}

.logo-text h2{

font-size:24px;

}

.logo-text h4{

font-size:16px;

}

.logo-text small{

display:none;

}

}

</style>