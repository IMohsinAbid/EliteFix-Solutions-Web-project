<template>
  <footer class="footer">

    <div class="footer-container">

      <!-- Company Info -->
      <div class="footer-col">

        <h2 class="logo">
          EliteFix Solutions
        </h2>

        <p>
          Providing professional AC maintenance,
          plumbing, electrical, home maintenance,
          soil work, and media wall services across Dubai.
        </p>

        <div class="socials">

          <a href="#">
            <i class="fab fa-facebook-f"></i>
          </a>

          <a href="#">
            <i class="fab fa-instagram"></i>
          </a>

          <a href="#">
            <i class="fab fa-linkedin-in"></i>
          </a>

          <a href="#">
            <i class="fab fa-whatsapp"></i>
          </a>

        </div>

      </div>

      <!-- Quick Links -->
      <div class="footer-col">

        <h3>Quick Links</h3>

        <ul>

          <li>
            <RouterLink to="/">Home</RouterLink>
          </li>

          <li>
            <RouterLink to="/about">About Us</RouterLink>
          </li>

          <li>
            <RouterLink to="/services">Services</RouterLink>
          </li>

          <li>
            <RouterLink to="/gallery">Gallery</RouterLink>
          </li>

          <li>
            <RouterLink to="/contact">Contact Us</RouterLink>
          </li>

        </ul>

      </div>

      <!-- Services -->
      <div class="footer-col">

        <h3>Our Services</h3>

        <ul>

          <li>
            <RouterLink to="/services/ac-maintenance">
              AC Maintenance
            </RouterLink>
          </li>

          <li>
            <RouterLink to="/services/plumbing">
              Plumbing Services
            </RouterLink>
          </li>

          <li>
            <RouterLink to="/services/electrical">
              Electrical Services
            </RouterLink>
          </li>

          <li>
            <RouterLink to="/services/home-maintenance">
              Home Maintenance
            </RouterLink>
          </li>

          <li>
            <RouterLink to="/services/soil-work">
              Soil Work
            </RouterLink>
          </li>

          <li>
            <RouterLink to="/services/media-wall">
              Media Wall Service
            </RouterLink>
          </li>

        </ul>

      </div>

      <!-- Contact -->
      <div class="footer-col">

        <h3>Contact Info</h3>

        <ul class="contact-info">

          <li>
            📍 Dubai, UAE
          </li>

          <li>
            📞 +971 50 123 4567
          </li>

          <li>
            ✉ info@elitefixsolutions.com
          </li>

          <li>
            🕒 Mon - Sat | 8AM - 8PM
          </li>

        </ul>

        <RouterLink
          to="/request-quote"
          class="footer-btn"
        >
          Request Quote
        </RouterLink>

      </div>

    </div>

    <!-- Bottom Footer -->

    <div class="footer-bottom">

      <p>
        © 2026 EliteFix Solutions. All Rights Reserved.
      </p>

    </div>

  </footer>
</template>

<script setup>
</script>

<style scoped>

.footer{

background:#081A38;

color:white;

padding-top:70px;

}

.footer-container{

display:grid;

grid-template-columns:
2fr
1fr
1fr
1.5fr;

gap:40px;

padding:0 8% 50px;

}

.logo{

font-size:32px;

color:#ff6b00;

margin-bottom:20px;

}

.footer-col p{

line-height:1.8;

color:#d9d9d9;

}

.footer-col h3{

margin-bottom:20px;

font-size:22px;

color:#fff;

}

.footer-col ul{

list-style:none;

}

.footer-col ul li{

margin-bottom:14px;

}

.footer-col a{

text-decoration:none;

color:#d9d9d9;

transition:.3s;

}

.footer-col a:hover{

color:#ff6b00;

}

.socials{

display:flex;

gap:15px;

margin-top:25px;

}

.socials a{

width:42px;

height:42px;

display:flex;

align-items:center;

justify-content:center;

border-radius:50%;

background:rgba(255,255,255,.1);

font-size:18px;

}

.socials a:hover{

background:#ff6b00;

color:white;

}

.contact-info li{

line-height:1.8;

}

.footer-btn{

display:inline-block;

margin-top:20px;

padding:12px 24px;

background:#ff6b00;

border-radius:8px;

color:white !important;

font-weight:600;

}

.footer-btn:hover{

background:#e55d00;

}

.footer-bottom{

border-top:1px solid rgba(255,255,255,.1);

padding:20px;

text-align:center;

color:#ccc;

}

@media(max-width:992px){

.footer-container{

grid-template-columns:1fr;

text-align:center;

}

.socials{

justify-content:center;

}

}

</style>