<template>
  <RouterView />
  <FloatingButtons />
</template>

<script setup>
import { RouterView } from 'vue-router'
import FloatingButtons from "@/components/FloatingButtons.vue"
</script>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:'Poppins',sans-serif;
}

body{
  background:#fff;
}

html,
body,
#app{
  width:100%;
  min-height:100%;
}
</style>