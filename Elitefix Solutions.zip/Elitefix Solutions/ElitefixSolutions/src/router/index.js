import { createRouter, createWebHistory } from 'vue-router'

import Home from '../views/Home.vue'
import About from '../views/About.vue'
import Services from '../views/Services.vue'
import Gallery from '../views/Gallery.vue'
import Contact from '../views/Contact.vue'
import RequestQuote from '../views/RequestQuote.vue'

import AcMaintenance from '../views/AcMaintainance.vue'
import Plumbing from '../views/Plumbing.vue'
import Electrical from '../views/Electrical.vue'
import HomeMaintenance from '../views/HomeMaintainance.vue'
import SoilWork from '../views/SoilWork.vue'
import MediaWall from '../views/MediaWall.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: Home
    },
    {
      path: '/about',
      component: About
    },
    {
      path: '/services',
      component: Services
    },
    {
      path: '/gallery',
      component: Gallery
    },
    {
      path: '/contact',
      component: Contact
    },
    {
      path: '/request-quote',
      component: RequestQuote
    },
    {
      path: '/services/ac-maintenance',
      component: AcMaintenance
    },
    {
      path: '/services/plumbing',
      component: Plumbing
    },
    {
      path: '/services/electrical',
      component: Electrical
    },
    {
      path: '/services/home-maintenance',
      component: HomeMaintenance
    },
    {
      path: '/services/soil-work',
      component: SoilWork
    },
    {
      path: '/services/media-wall',
      component: MediaWall
    }
  ]
})

export default router