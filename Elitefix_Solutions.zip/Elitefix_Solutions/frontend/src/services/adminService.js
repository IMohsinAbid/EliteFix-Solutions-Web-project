import axiosClient from './axiosClient'

/**
 * Log an admin in. On success, stores the JWT + admin profile in
 * localStorage so the session survives a page refresh.
 */
async function login(email, password) {
  const { data } = await axiosClient.post('/admin/login', { email, password })

  if (data?.token) {
    localStorage.setItem('adminToken', data.token)
    localStorage.setItem('adminUser', JSON.stringify(data.admin))
  }

  return data
}

/** Clears the stored session. Does not need a backend call since JWTs are stateless. */
function logout() {
  localStorage.removeItem('adminToken')
  localStorage.removeItem('adminUser')
}

function isAuthenticated() {
  return Boolean(localStorage.getItem('adminToken'))
}

function getStoredAdmin() {
  const raw = localStorage.getItem('adminUser')
  return raw ? JSON.parse(raw) : null
}

/** Verifies the stored token is still valid against the backend. */
async function fetchCurrentAdmin() {
  const { data } = await axiosClient.get('/admin/me')
  return data.admin
}

async function fetchDashboardStats() {
  const { data } = await axiosClient.get('/admin/stats')
  return data.data
}

export default { login, logout, isAuthenticated, getStoredAdmin, fetchCurrentAdmin, fetchDashboardStats }
