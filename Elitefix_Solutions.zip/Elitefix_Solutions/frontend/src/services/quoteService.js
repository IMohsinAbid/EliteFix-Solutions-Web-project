import axiosClient from './axiosClient'

/**
 * List quote requests, newest first. Pass `search` to filter by
 * name/email/phone (server-side, case-insensitive).
 */
async function getQuotes(search = '') {
  const { data } = await axiosClient.get('/quotes', {
    params: search ? { search } : {},
  })
  return data.data
}

async function deleteQuote(id) {
  const { data } = await axiosClient.delete(`/quotes/${id}`)
  return data
}

async function updateQuoteStatus(id, status) {
  const { data } = await axiosClient.patch(`/quotes/${id}/status`, { status })
  return data.data
}

export default { getQuotes, deleteQuote, updateQuoteStatus }
