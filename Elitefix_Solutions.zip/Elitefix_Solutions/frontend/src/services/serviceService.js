import axiosClient from './axiosClient'

async function getServices() {
  const { data } = await axiosClient.get('/services')
  return data.data
}

async function createService(payload) {
  const { data } = await axiosClient.post('/services', payload)
  return data.data
}

async function updateService(id, payload) {
  const { data } = await axiosClient.patch(`/services/${id}`, payload)
  return data.data
}

async function deleteService(id) {
  const { data } = await axiosClient.delete(`/services/${id}`)
  return data
}

export default { getServices, createService, updateService, deleteService }
