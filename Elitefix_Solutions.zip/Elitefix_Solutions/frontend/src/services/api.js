const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

/**
 * Low-level POST helper. Throws an Error with a readable message on failure,
 * and attaches any field-level validation errors returned by the API.
 */
async function postJSON(path, payload) {
  let response
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
  } catch (networkErr) {
    const err = new Error('Could not reach the server. Please check your connection and try again.')
    err.cause = networkErr
    throw err
  }

  let data = null
  try {
    data = await response.json()
  } catch (_) {
    // no JSON body
  }

  if (!response.ok) {
    const message = data?.message || 'Something went wrong. Please try again.'
    const err = new Error(message)
    err.status = response.status
    err.errors = data?.errors || null
    throw err
  }

  return data
}

/**
 * Submit a "Request a Quote" form.
 * Expects: { name, email, phone, location, service, message }
 */
export function submitQuote(payload) {
  return postJSON('/quotes', payload)
}

/**
 * Submit a "Contact Us" form.
 * Expects: { name, email, phone, service, message }
 */
export function submitContact(payload) {
  return postJSON('/contact', payload)
}

export default { submitQuote, submitContact }
