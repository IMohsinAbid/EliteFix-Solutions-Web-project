<template>
  <div class="admin-layout">
    <AdminSidebar />

    <main class="admin-main">
      <header class="admin-header">
        <div>
          <h1>Dashboard</h1>
          <p>Overview of your quote requests and services.</p>
        </div>
      </header>

      <p v-if="errorMessage" class="alert alert-danger">{{ errorMessage }}</p>

      <div v-if="loading" class="text-muted">Loading stats...</div>

      <div v-else class="row g-4 stats-row">
        <div class="col-12 col-md-4">
          <div class="card stat-card">
            <div class="stat-icon bg-orange"><i class="fa-solid fa-file-invoice"></i></div>
            <div>
              <div class="stat-value">{{ stats.totalQuotes }}</div>
              <div class="stat-label">Total Quote Requests</div>
            </div>
          </div>
        </div>

        <div class="col-12 col-md-4">
          <div class="card stat-card">
            <div class="stat-icon bg-navy"><i class="fa-solid fa-screwdriver-wrench"></i></div>
            <div>
              <div class="stat-value">{{ stats.totalServices }}</div>
              <div class="stat-label">Total Services</div>
            </div>
          </div>
        </div>

        <div class="col-12 col-md-4">
          <div class="card stat-card">
            <div class="stat-icon bg-green"><i class="fa-solid fa-clock"></i></div>
            <div>
              <div class="stat-value">{{ stats.pendingQuotes }}</div>
              <div class="stat-label">Pending Requests</div>
            </div>
          </div>
        </div>
      </div>

      <div class="quick-links mt-4">
        <RouterLink to="/admin/quotes" class="btn btn-outline-primary me-3">
          View Quotes <i class="fa-solid fa-arrow-right ms-1"></i>
        </RouterLink>
        <RouterLink to="/admin/services" class="btn btn-outline-primary">
          Manage Services <i class="fa-solid fa-arrow-right ms-1"></i>
        </RouterLink>
      </div>
    </main>
  </div>
</template>

<script setup>
import 'bootstrap/dist/css/bootstrap.min.css'
import { onMounted, reactive, ref } from 'vue'
import AdminSidebar from '@/components/admin/AdminSidebar.vue'
import adminService from '@/services/adminService'

const stats = reactive({ totalQuotes: 0, totalServices: 0, pendingQuotes: 0 })
const loading = ref(true)
const errorMessage = ref('')

onMounted(async () => {
  try {
    const data = await adminService.fetchDashboardStats()
    stats.totalQuotes = data.totalQuotes
    stats.totalServices = data.totalServices
    stats.pendingQuotes = data.pendingQuotes
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not load dashboard stats.'
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.admin-layout {
  display: grid;
  grid-template-columns: 260px 1fr;
  min-height: 100vh;
  background: #f5f7fb;
  font-family: 'Poppins', sans-serif;
}

.admin-main {
  padding: 36px 40px;
}

.admin-header h1 {
  font-size: 26px;
  color: #081a38;
  margin-bottom: 4px;
}

.admin-header p {
  color: #667085;
  margin-bottom: 28px;
}

.stat-card {
  border: none;
  border-radius: 16px;
  padding: 24px;
  display: flex;
  align-items: center;
  gap: 18px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  height: 100%;
}

.stat-icon {
  width: 54px;
  height: 54px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 20px;
  flex-shrink: 0;
}

.bg-orange {
  background: #ff6b00;
}

.bg-navy {
  background: #081a38;
}

.bg-green {
  background: #16a34a;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #081a38;
  line-height: 1;
}

.stat-label {
  color: #667085;
  font-size: 13.5px;
  margin-top: 6px;
}

@media (max-width: 900px) {
  .admin-layout {
    grid-template-columns: 1fr;
  }
}
</style>
