<template>

<Navbar/>

<!-- Hero -->

<section class="hero">

    <div class="overlay">

        <h4>OUR SERVICES</h4>

        <h1>
            Professional Home Maintenance
            Services in Dubai
        </h1>

        <p>

            EliteFix Solutions provides reliable
            maintenance and renovation services
            for residential and commercial properties.

        </p>

    </div>

</section>

<!-- Intro -->

<section class="intro">

    <h2>
        Complete Home Maintenance Solutions
    </h2>

    <p>

        We offer professional technical services
        delivered by experienced technicians
        using modern equipment and quality materials.

    </p>

</section>

<!-- Services -->

<section class="services">

<div
class="card"

v-for="service in services"

:key="service.title"
>

<div class="content">

<h3>{{service.title}}</h3>

<p>

{{service.description}}

</p>

<RouterLink
:to="service.link">

Learn More →

</RouterLink>

</div>

</div>

</section>

<!-- Work Process -->

<section class="process">

<h2>

Our Working Process

</h2>

<div class="steps">

<div class="step">

<h3>1</h3>

<h4>Request Quote</h4>

</div>

<div class="step">

<h3>2</h3>

<h4>Site Inspection</h4>

</div>

<div class="step">

<h3>3</h3>

<h4>Free Estimate</h4>

</div>

<div class="step">

<h3>4</h3>

<h4>Service Delivery</h4>

</div>

</div>

</section>

<!-- FAQ -->

<section class="faq">

<h2>

Frequently Asked Questions

</h2>

<div class="faq-item">

<h3>

Do you provide same day service?

</h3>

<p>

Yes, depending on availability.

</p>

</div>

<div class="faq-item">

<h3>

Do you work on weekends?

</h3>

<p>

Yes, we serve customers throughout the week.

</p>

</div>

<div class="faq-item">

<h3>

Is site inspection free?

</h3>

<p>

Yes, for most maintenance services.

</p>

</div>

</section>

<RequestQuoteSection/>

<Footer/>

</template>

<script setup>

import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";
import RequestQuoteSection from "@/components/RequestQuoteSection.vue";
import { computed, onMounted, ref } from "vue";
import serviceService from "@/services/serviceService";

// The 6 core services each have a dedicated detail page, so they stay hardcoded.
const coreServices=[

{

title:"AC Maintenance",

image:"/images/services/ac.jpg",

description:"Professional AC installation, repair and maintenance services.",

link:"/services/ac-maintenance"

},

{

title:"Plumbing",

image:"/images/services/plumbing.jpg",

description:"Leak detection, drainage and pipe installation.",

link:"/services/plumbing"

},

{

title:"Electrical",

image:"/images/services/electrical.jpg",

description:"Electrical repairs and installations by certified technicians.",

link:"/services/electrical"

},

{

title:"Home Maintenance",

image:"/images/services/home-maintenance.jpg",

description:"Complete maintenance solutions for your property.",

link:"/services/home-maintenance"

},

{

title:"Soil Work",

image:"/images/services/soil-work.jpg",

description:"Excavation and site preparation services.",

link:"/services/soil-work"

},

{

title:"Media Wall",

image:"/images/services/media-wall.jpg",

description:"Modern TV media wall design and installation.",

link:"/services/media-wall"

}

]

// Services added through the admin panel, fetched from the backend and
// shown after the core 6. They don't have a dedicated detail page yet,
// so "Learn More" sends visitors to Request a Quote instead.
const adminServices = ref([])

onMounted(async () => {
  try {
    const data = await serviceService.getServices()
    adminServices.value = data.map((service) => ({
      title: service.name,
      description: service.description,
      link: "/request-quote"
    }))
  } catch (err) {
    // Non-critical for the public services page — just fall back to the core list.
    console.error("Could not load additional services:", err.message)
  }
})

const services = computed(() => [...coreServices, ...adminServices.value])
</script>

<style scoped>

.hero{

height:55vh;

background:url('/images/services/services-banner.jpg');

background-size:cover;

background-position:center;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

color:white;

text-align:center;

padding:20px;

}

.overlay h4{

color:#ff6b00;

margin-bottom:15px;

}

.overlay h1{

font-size:50px;

margin-bottom:20px;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.intro{

padding:80px 8%;

text-align:center;

}

.intro h2{

font-size:40px;

color:#081A38;

margin-bottom:20px;

}

.intro p{

max-width:700px;

margin:auto;

line-height:1.8;

color:#666;

}

.services{

padding:0 8% 100px;

display:grid;

grid-template-columns:repeat(3,1fr);

gap:35px;

}

.card{

background:white;

border-radius:20px;

overflow:hidden;

box-shadow:0 8px 25px rgba(0,0,0,.08);

transition:.3s;

}

.card:hover{

transform:translateY(-8px);

}

.card img{

width:100%;

height:220px;

object-fit:cover;

}

.content{

padding:25px;

}

.content h3{

margin-bottom:15px;

color:#081A38;

}

.content p{

line-height:1.8;

color:#666;

margin-bottom:20px;

}

.content a{

color:#ff6b00;

font-weight:bold;

text-decoration:none;

}

.process{

padding:100px 8%;

background:#f7f8fa;

text-align:center;

}

.steps{

margin-top:50px;

display:grid;

grid-template-columns:repeat(4,1fr);

gap:25px;

}

.step{

background:white;

padding:35px;

border-radius:16px;

}

.step h3{

width:70px;

height:70px;

background:#ff6b00;

color:white;

border-radius:50%;

margin:auto;

display:flex;

justify-content:center;

align-items:center;

font-size:28px;

margin-bottom:20px;

}

.faq{

padding:100px 8%;

}

.faq h2{

text-align:center;

margin-bottom:40px;

font-size:40px;

color:#081A38;

}

.faq-item{

background:#f8f8f8;

padding:25px;

margin-bottom:20px;

border-radius:12px;

}

@media(max-width:992px){

.services{

grid-template-columns:1fr;

}

.steps{

grid-template-columns:1fr;

}

.overlay h1{

font-size:36px;

}

}

</style>