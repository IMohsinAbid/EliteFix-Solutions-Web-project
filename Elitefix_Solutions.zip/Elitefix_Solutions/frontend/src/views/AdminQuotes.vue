<template>
  <div class="admin-layout">
    <AdminSidebar />

    <main class="admin-main">
      <header class="admin-header">
        <div>
          <h1>Quote Requests</h1>
          <p>Every "Request a Quote" submission from the main site, newest first.</p>
        </div>
      </header>

      <div class="toolbar">
        <div class="search-box">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input
            type="text"
            v-model="searchTerm"
            placeholder="Search by name, email, or phone..."
            @input="onSearchInput"
          />
        </div>
        <span class="result-count" v-if="!loading">{{ quotes.length }} result{{ quotes.length === 1 ? '' : 's' }}</span>
      </div>

      <p v-if="errorMessage" class="alert alert-danger">{{ errorMessage }}</p>

      <div v-if="loading" class="text-muted">Loading quote requests...</div>

      <div v-else class="table-card">
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Service</th>
                <th>Address</th>
                <th>Message</th>
                <th>Date Submitted</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="quotes.length === 0">
                <td colspan="8" class="text-center text-muted py-4">No quote requests found.</td>
              </tr>
              <tr v-for="quote in quotes" :key="quote._id">
                <td>{{ quote.name }}</td>
                <td>{{ quote.email }}</td>
                <td>{{ quote.phone }}</td>
                <td><span class="badge-service">{{ quote.service }}</span></td>
                <td>{{ quote.location || '—' }}</td>
                <td class="message-cell" :title="quote.message">{{ quote.message }}</td>
                <td class="text-nowrap">{{ formatDate(quote.createdAt) }}</td>
                <td class="text-end">
                  <button
                    class="btn btn-sm btn-outline-danger"
                    :disabled="deletingId === quote._id"
                    @click="handleDelete(quote)"
                  >
                    <i class="fa-solid fa-trash"></i>
                    {{ deletingId === quote._id ? 'Deleting...' : 'Delete' }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import 'bootstrap/dist/css/bootstrap.min.css'
import { onMounted, ref } from 'vue'
import AdminSidebar from '@/components/admin/AdminSidebar.vue'
import quoteService from '@/services/quoteService'

const quotes = ref([])
const loading = ref(true)
const errorMessage = ref('')
const searchTerm = ref('')
const deletingId = ref(null)

let searchDebounce = null

const loadQuotes = async (search = '') => {
  errorMessage.value = ''
  try {
    quotes.value = await quoteService.getQuotes(search)
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not load quote requests.'
  }
}

onMounted(async () => {
  loading.value = true
  await loadQuotes()
  loading.value = false
})

// Debounce search input so we're not firing a request on every keystroke,
// while still updating the table "instantly" from the user's perspective.
const onSearchInput = () => {
  clearTimeout(searchDebounce)
  searchDebounce = setTimeout(() => {
    loadQuotes(searchTerm.value)
  }, 300)
}

const handleDelete = async (quote) => {
  const confirmed = window.confirm('Are you sure you want to delete this request?')
  if (!confirmed) return

  deletingId.value = quote._id
  errorMessage.value = ''

  try {
    await quoteService.deleteQuote(quote._id)
    quotes.value = quotes.value.filter((q) => q._id !== quote._id)
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not delete this request.'
  } finally {
    deletingId.value = null
  }
}

const formatDate = (isoString) => {
  if (!isoString) return '—'
  return new Date(isoString).toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}
</script>

<style scoped>
.admin-layout {
  display: grid;
  grid-template-columns: 260px 1fr;
  min-height: 100vh;
  background: #f5f7fb;
  font-family: 'Poppins', sans-serif;
}

.admin-main {
  padding: 36px 40px;
}

.admin-header h1 {
  font-size: 26px;
  color: #081a38;
  margin-bottom: 4px;
}

.admin-header p {
  color: #667085;
  margin-bottom: 24px;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff;
  border: 1px solid #e2e6ee;
  border-radius: 10px;
  padding: 10px 16px;
  width: 100%;
  max-width: 420px;
}

.search-box i {
  color: #98a2b3;
}

.search-box input {
  border: none;
  outline: none;
  width: 100%;
  font-size: 14.5px;
}

.result-count {
  color: #667085;
  font-size: 13.5px;
  white-space: nowrap;
}

.table-card {
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  overflow: hidden;
}

.table thead th {
  background: #f8f9fb;
  color: #667085;
  font-size: 12.5px;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  border-bottom: 1px solid #eef0f4;
  padding: 14px 16px;
  white-space: nowrap;
}

.table tbody td {
  padding: 14px 16px;
  font-size: 14px;
  color: #101828;
  border-bottom: 1px solid #f2f4f7;
}

.message-cell {
  max-width: 260px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.badge-service {
  background: #fff1e6;
  color: #ff6b00;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 600;
  white-space: nowrap;
}

@media (max-width: 900px) {
  .admin-layout {
    grid-template-columns: 1fr;
  }
}
</style>
