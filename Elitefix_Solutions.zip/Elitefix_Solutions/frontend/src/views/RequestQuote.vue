<template>

  <Navbar/>

  <!-- Hero -->

  <section class="hero">

    <div class="overlay">

      <h4>REQUEST A QUOTE</h4>

      <h1>
        Get Your Free Estimate Today
      </h1>

      <p>

        Tell us about your project and our
        team will contact you with a free
        quotation.

      </p>

    </div>

  </section>

  <!-- Quote Form -->

  <section class="quote">

    <!-- Left -->

    <div class="image">

     

    </div>

    <!-- Right -->

    <div class="form">

      <h2>Request a Free Quote</h2>

      <p>

        Fill out the form below and our
        representative will contact you shortly.

      </p>

      <form @submit.prevent="submitQuote">

        <input
          type="text"
          v-model="form.name"
          placeholder="Full Name"
          required>

        <input
          type="email"
          v-model="form.email"
          placeholder="Email Address"
          required>

        <input
          type="tel"
          v-model="form.phone"
          placeholder="Phone Number"
          required>

        <input
          type="text"
          v-model="form.location"
          placeholder="Location (Dubai Area)"
          required>

        <select
          v-model="form.service"
          required>

          <option value="">
            Select Service
          </option>

          <option>AC Maintenance</option>

          <option>Plumbing</option>

          <option>Electrical</option>

          <option>Home Maintenance</option>

          <option>Soil Work</option>

          <option>Media Wall</option>

        </select>

        <textarea

          rows="6"

          v-model="form.message"

          placeholder="Describe Your Project"

          required>

        </textarea>

        <p v-if="errorMessage" class="form-error">{{ errorMessage }}</p>

        <button :disabled="submitting">

          {{ submitting ? 'Submitting...' : 'Request Quote' }}

        </button>

      </form>

    </div>

  </section>

  <!-- Why Request Quote -->

  <section class="benefits">

    <h2>

      Why Choose EliteFix?

    </h2>

    <div class="cards">

      <div class="card">

        💰

        <h3>Free Estimates</h3>

        <p>

          No hidden charges.
          Get a completely free quotation.

        </p>

      </div>

      <div class="card">

        ⚡

        <h3>Fast Response</h3>

        <p>

          We usually respond within
          a few hours.

        </p>

      </div>

      <div class="card">

        ⭐

        <h3>Trusted Experts</h3>

        <p>

          Professional technicians
          with years of experience.

        </p>

      </div>

    </div>

  </section>

  <Footer/>

</template>

<script setup>

import { reactive, ref } from "vue"

import Navbar from "@/components/Navbar.vue"
import Footer from "@/components/Footer.vue"
import api from "@/services/api"

const form = reactive({

name:"",
email:"",
phone:"",
location:"",
service:"",
message:""

})

const submitting = ref(false)
const errorMessage = ref("")

const submitQuote = async () => {

  errorMessage.value = ""
  submitting.value = true

  try {
    await api.submitQuote({ ...form })

    alert("Quote Request Submitted Successfully!")

    // Reset the form after a successful submission
    form.name = ""
    form.email = ""
    form.phone = ""
    form.location = ""
    form.service = ""
    form.message = ""
  } catch (err) {
    errorMessage.value = err.message || "Something went wrong. Please try again."
  } finally {
    submitting.value = false
  }

}

</script>

<style scoped>

.hero{

height:55vh;

background:url('/images/quote/quote-banner.jpg') center/cover no-repeat;

}

.overlay{

height:100%;

background:rgba(8,26,56,.75);

display:flex;

flex-direction:column;

justify-content:center;

align-items:center;

text-align:center;

color:white;

padding:20px;

}

.overlay h4{

color:#ff6b00;

letter-spacing:2px;

}

.overlay h1{

font-size:50px;

margin:20px 0;

}

.overlay p{

max-width:700px;

line-height:1.8;

}

.quote{

padding:100px 8%;

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

align-items:center;

}

.image img{

width:100%;

border-radius:20px;

}

.form h2{

font-size:40px;

color:#081A38;

margin-bottom:20px;

}

.form p{

margin-bottom:30px;

color:#666;

}

form{

display:flex;

flex-direction:column;

gap:18px;

}

input,
select,
textarea{

padding:15px;

border:1px solid #ddd;

border-radius:10px;

font-size:16px;

outline:none;

}

input:focus,
select:focus,
textarea:focus{

border-color:#ff6b00;

}

button{

background:#ff6b00;

color:white;

padding:15px;

border:none;

border-radius:10px;

font-size:18px;

cursor:pointer;

transition:.3s;

}

button:hover{

background:#e45b00;

}

button:disabled{

background:#ffb380;
cursor:not-allowed;

}

.form-error{

color:#d92d20;
background:#fdecea;
padding:12px 15px;
border-radius:10px;
font-size:14px;
margin:0;

}

.benefits{

padding:100px 8%;

background:#f8f9fb;

text-align:center;

}

.cards{

display:grid;

grid-template-columns:repeat(3,1fr);

gap:30px;

margin-top:40px;

}

.card{

background:white;

padding:40px;

border-radius:18px;

box-shadow:0 10px 25px rgba(0,0,0,.08);

}

.card h3{

margin:20px 0;

color:#081A38;

}

@media(max-width:992px){

.quote{

grid-template-columns:1fr;

}

.cards{

grid-template-columns:1fr;

}

.overlay h1{

font-size:36px;

}

}

</style>