<template>
  <div class="admin-login-page">
    <div class="login-card">
      <div class="login-brand">
        <span class="brand-mark">EF</span>
        <h1>EliteFix Admin</h1>
        <p>Sign in to manage quotes and services.</p>
      </div>

      <form @submit.prevent="handleLogin" novalidate>
        <div class="mb-3">
          <label class="form-label" for="email">Email</label>
          <input
            id="email"
            v-model.trim="form.email"
            type="email"
            class="form-control"
            placeholder="admin@elitefixsolutions.com"
            autocomplete="username"
            required
          />
        </div>

        <div class="mb-3">
          <label class="form-label" for="password">Password</label>
          <input
            id="password"
            v-model="form.password"
            type="password"
            class="form-control"
            placeholder="••••••••"
            autocomplete="current-password"
            required
          />
        </div>

        <p v-if="errorMessage" class="alert alert-danger py-2 px-3 mb-3">
          {{ errorMessage }}
        </p>

        <button type="submit" class="btn btn-warning w-100 login-btn" :disabled="submitting">
          {{ submitting ? 'Signing in...' : 'Login' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import 'bootstrap/dist/css/bootstrap.min.css'
import { reactive, ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import adminService from '@/services/adminService'

const router = useRouter()
const route = useRoute()

const form = reactive({ email: '', password: '' })
const submitting = ref(false)
const errorMessage = ref('')

const handleLogin = async () => {
  errorMessage.value = ''
  submitting.value = true

  try {
    await adminService.login(form.email, form.password)

    // Send the admin back to wherever they were headed, or the dashboard.
    const redirectTo = route.query.redirect || '/admin/dashboard'
    router.push(redirectTo)
  } catch (err) {
    errorMessage.value =
      err.response?.data?.message || 'Invalid email or password. Please try again.'
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.admin-login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #081a38 0%, #0f2a56 100%);
  padding: 20px;
}

.login-card {
  background: #fff;
  border-radius: 20px;
  padding: 44px 38px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
}

.login-brand {
  text-align: center;
  margin-bottom: 28px;
}

.brand-mark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 52px;
  height: 52px;
  border-radius: 14px;
  background: #ff6b00;
  color: #fff;
  font-weight: 700;
  font-size: 18px;
  margin-bottom: 14px;
}

.login-brand h1 {
  font-size: 24px;
  color: #081a38;
  margin-bottom: 6px;
}

.login-brand p {
  color: #667085;
  font-size: 14px;
  margin: 0;
}

.form-label {
  font-weight: 600;
  color: #081a38;
  font-size: 13.5px;
}

.form-control {
  padding: 12px 14px;
  border-radius: 10px;
}

.form-control:focus {
  border-color: #ff6b00;
  box-shadow: 0 0 0 0.2rem rgba(255, 107, 0, 0.15);
}

.login-btn {
  background: #ff6b00;
  border: none;
  padding: 12px;
  font-weight: 600;
  border-radius: 10px;
  color: #fff;
}

.login-btn:hover:not(:disabled) {
  background: #e45b00;
  color: #fff;
}

.login-btn:disabled {
  opacity: 0.7;
}
</style>
