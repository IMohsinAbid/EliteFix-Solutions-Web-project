<template>
  <div class="admin-layout">
    <AdminSidebar />

    <main class="admin-main">
      <header class="admin-header">
        <div>
          <h1>Manage Services</h1>
          <p>Add or remove the services shown on the public site.</p>
        </div>
      </header>

      <p v-if="errorMessage" class="alert alert-danger">{{ errorMessage }}</p>

      <!-- Add service form -->
      <div class="form-card mb-4">
        <h2>Add a Service</h2>
        <form @submit.prevent="handleCreate" class="service-form">
          <div class="row g-3">
            <div class="col-12 col-md-6">
              <label class="form-label">Service Name</label>
              <input
                type="text"
                class="form-control"
                v-model.trim="newService.name"
                placeholder="e.g. AC Maintenance"
                required
              />
            </div>

            <div class="col-12 col-md-6">
              <label class="form-label">Icon / Image URL</label>
              <input
                type="text"
                class="form-control"
                v-model.trim="newService.icon"
                placeholder="fa-solid fa-fan or an image URL"
              />
            </div>

            <div class="col-12 col-md-6">
              <label class="form-label">Price (optional)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                class="form-control"
                v-model="newService.price"
                placeholder="e.g. 150"
              />
            </div>

            <div class="col-12">
              <label class="form-label">Description</label>
              <textarea
                class="form-control"
                rows="3"
                v-model.trim="newService.description"
                placeholder="Short description of the service"
                required
              ></textarea>
            </div>
          </div>

          <button type="submit" class="btn btn-warning add-btn" :disabled="creating">
            <i class="fa-solid fa-plus"></i>
            {{ creating ? 'Adding...' : 'Add Service' }}
          </button>
        </form>
      </div>

      <!-- Services list -->
      <div v-if="loading" class="text-muted">Loading services...</div>

      <div v-else class="services-grid">
        <div v-if="services.length === 0" class="text-muted">No services yet. Add your first one above.</div>

        <div class="service-card" v-for="service in services" :key="service._id">
          <div class="service-icon">
            <img v-if="isImageUrl(service.icon)" :src="service.icon" :alt="service.name" />
            <i v-else :class="service.icon || 'fa-solid fa-screwdriver-wrench'"></i>
          </div>
          <div class="service-body">
            <h3>{{ service.name }}</h3>
            <p>{{ service.description }}</p>
            <span v-if="service.price" class="price">From ${{ service.price }}</span>
          </div>
          <button
            class="btn btn-sm btn-outline-danger delete-btn"
            :disabled="deletingId === service._id"
            @click="handleDelete(service)"
          >
            <i class="fa-solid fa-trash"></i>
            {{ deletingId === service._id ? 'Deleting...' : 'Delete' }}
          </button>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import 'bootstrap/dist/css/bootstrap.min.css'
import { onMounted, reactive, ref } from 'vue'
import AdminSidebar from '@/components/admin/AdminSidebar.vue'
import serviceService from '@/services/serviceService'

const services = ref([])
const loading = ref(true)
const creating = ref(false)
const deletingId = ref(null)
const errorMessage = ref('')

const newService = reactive({
  name: '',
  description: '',
  icon: '',
  price: '',
})

const loadServices = async () => {
  errorMessage.value = ''
  try {
    services.value = await serviceService.getServices()
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not load services.'
  }
}

onMounted(async () => {
  loading.value = true
  await loadServices()
  loading.value = false
})

const handleCreate = async () => {
  errorMessage.value = ''
  creating.value = true

  try {
    const payload = {
      name: newService.name,
      description: newService.description,
      icon: newService.icon || undefined,
      price: newService.price !== '' ? Number(newService.price) : undefined,
    }

    const created = await serviceService.createService(payload)
    services.value.unshift(created)

    newService.name = ''
    newService.description = ''
    newService.icon = ''
    newService.price = ''
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not add this service.'
  } finally {
    creating.value = false
  }
}

const handleDelete = async (service) => {
  const confirmed = window.confirm(`Are you sure you want to delete "${service.name}"?`)
  if (!confirmed) return

  deletingId.value = service._id
  errorMessage.value = ''

  try {
    await serviceService.deleteService(service._id)
    services.value = services.value.filter((s) => s._id !== service._id)
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Could not delete this service.'
  } finally {
    deletingId.value = null
  }
}

// Icon field can either be a FontAwesome class ("fa-solid fa-fan") or an
// image URL ("https://.../icon.png"). Render accordingly.
const isImageUrl = (value) => {
  if (!value) return false
  return /^https?:\/\//i.test(value) || /\.(png|jpe?g|svg|webp|gif)$/i.test(value)
}
</script>

<style scoped>
.admin-layout {
  display: grid;
  grid-template-columns: 260px 1fr;
  min-height: 100vh;
  background: #f5f7fb;
  font-family: 'Poppins', sans-serif;
}

.admin-main {
  padding: 36px 40px;
}

.admin-header h1 {
  font-size: 26px;
  color: #081a38;
  margin-bottom: 4px;
}

.admin-header p {
  color: #667085;
  margin-bottom: 24px;
}

.form-card {
  background: #fff;
  border-radius: 16px;
  padding: 28px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
}

.form-card h2 {
  font-size: 18px;
  color: #081a38;
  margin-bottom: 18px;
}

.form-label {
  font-weight: 600;
  color: #081a38;
  font-size: 13.5px;
}

.form-control {
  border-radius: 10px;
  padding: 10px 14px;
}

.form-control:focus {
  border-color: #ff6b00;
  box-shadow: 0 0 0 0.2rem rgba(255, 107, 0, 0.15);
}

.add-btn {
  background: #ff6b00;
  border: none;
  color: #fff;
  font-weight: 600;
  padding: 10px 22px;
  border-radius: 10px;
  margin-top: 20px;
}

.add-btn:hover:not(:disabled) {
  background: #e45b00;
  color: #fff;
}

.add-btn:disabled {
  opacity: 0.7;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 20px;
}

.service-card {
  background: #fff;
  border-radius: 16px;
  padding: 22px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.service-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: #fff1e6;
  color: #ff6b00;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}

.service-icon img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 12px;
}

.service-body h3 {
  font-size: 16px;
  color: #081a38;
  margin-bottom: 6px;
}

.service-body p {
  color: #667085;
  font-size: 13.5px;
  line-height: 1.6;
}

.price {
  display: inline-block;
  font-weight: 600;
  color: #16a34a;
  font-size: 13.5px;
}

.delete-btn {
  align-self: flex-start;
  margin-top: 4px;
}

@media (max-width: 900px) {
  .admin-layout {
    grid-template-columns: 1fr;
  }
}
</style>
