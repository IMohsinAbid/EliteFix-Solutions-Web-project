<template>
  <section class="services">

    <div class="section-title">
      <span>OUR SERVICES</span>

      <h2>What We Offer</h2>

      <p>
        We provide reliable technical and maintenance services
        across Dubai with experienced professionals.
      </p>
    </div>

    <div class="service-grid">

      <ServiceCard
        v-for="service in services"
        :key="service.title"
        :title="service.title"
        :icon="service.icon"
        :image="service.image"
        :description="service.description"
        :link="service.link"
        @view-service="goToService"
      />

    </div>

  </section>
</template>

<script setup>
import { computed, onMounted, ref } from "vue"
import ServiceCard from "@/components/ServiceCard.vue"
import { useRouter } from "vue-router"
import serviceService from "@/services/serviceService"

const router = useRouter()

const goToService = (route) => {
  router.push(route)
}

// The 6 core services each have a dedicated detail page, so they stay hardcoded.
const coreServices = [
  {
    title: "AC Maintenance",
    icon: "❄️",
    image: "/images/ac.jpg",
    description:
      "Professional AC repair, installation and maintenance services for residential and commercial properties.",
    link: "/services/ac-maintenance"
  },
  {
    title: "Plumbing Services",
    icon: "🚰",
    image: "/images/plumbing.jpg",
    description:
      "Leak repairs, drainage solutions, pipe installation and complete plumbing maintenance.",
    link: "/services/plumbing"
  },
  {
    title: "Electrical Services",
    icon: "⚡",
    image: "/images/electrical.jpg",
    description:
      "Electrical installation, wiring, troubleshooting and maintenance by certified electricians.",
    link: "/services/electrical"
  },
  {
    title: "Home Maintenance",
    icon: "🏠",
    image: "/images/home.jpg",
    description:
      "General home repair and maintenance services to keep your property in excellent condition.",
    link: "/services/home-maintenance"
  },
  {
    title: "Soil Work & Maintenance",
    icon: "🚜",
    image: "/images/soil.jpg",
    description:
      "Excavation, levelling, backfilling and site preparation with professional equipment.",
    link: "/services/soil-work"
  },
  {
    title: "Media Wall Service",
    icon: "📺",
    image: "/images/mediawall.jpg",
    description:
      "Custom media wall design and installation to give your home a modern appearance.",
    link: "/services/media-wall"
  }
]

// Services added through the admin panel — fetched from the backend and
// appended after the core 6. They don't have a dedicated detail page yet,
// so "Learn More" sends visitors to Request a Quote instead.
const adminServices = ref([])

const isImageUrl = (value) => {
  if (!value) return false
  return /^https?:\/\//i.test(value) || /\.(png|jpe?g|svg|webp|gif)$/i.test(value)
}

onMounted(async () => {
  try {
    const data = await serviceService.getServices()
    adminServices.value = data.map((service) => ({
      title: service.name,
      icon: isImageUrl(service.icon) ? "🔧" : (service.icon || "🔧"),
      image: isImageUrl(service.icon) ? service.icon : "",
      description: service.description,
      link: "/request-quote"
    }))
  } catch (err) {
    // Non-critical for the public homepage — just fall back to the core list.
    console.error("Could not load additional services:", err.message)
  }
})

const services = computed(() => [...coreServices, ...adminServices.value])
</script>

<style scoped>

.services{
  padding:90px 8%;
  background:#f8f9fb;
}

.section-title{
  text-align:center;
  margin-bottom:60px;
}

.section-title span{
  color:#ff6b00;
  font-weight:bold;
  letter-spacing:2px;
}

.section-title h2{
  font-size:42px;
  margin:15px 0;
  color:#081A38;
}

.section-title p{
  color:#666;
  max-width:700px;
  margin:auto;
  line-height:1.8;
}

.service-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:35px;
}

@media(max-width:992px){

.service-grid{
  grid-template-columns:1fr;
}

.section-title h2{
  font-size:34px;
}

}

</style>