<template>
  <section class="quote-section">

    <div class="quote-container">

      <!-- Left Side -->
      <div class="quote-content">

        <span class="subtitle">GET A FREE QUOTE</span>

        <h2>
          Need Professional Home Maintenance Services?
        </h2>

        <p>
          Whether it's AC maintenance, plumbing, electrical work,
          home maintenance, soil work, or media wall installation,
          our expert team is ready to help.
        </p>

        <div class="benefits">

          <div class="benefit">
            ✅ Free Site Inspection
          </div>

          <div class="benefit">
            ✅ Fast Response
          </div>

          <div class="benefit">
            ✅ Affordable Pricing
          </div>

          <div class="benefit">
            ✅ Experienced Technicians
          </div>

        </div>

      </div>

      <!-- Right Side -->
      <div class="quote-form">

        <h3>Request a Quote</h3>

        <form @submit.prevent="submitForm">

          <input
            type="text"
            placeholder="Full Name"
            v-model="form.name"
            required
          />

          <input
            type="tel"
            placeholder="Phone Number"
            v-model="form.phone"
            required
          />

          <input
            type="email"
            placeholder="Email Address"
            v-model="form.email"
            required
          />

          <input
            type="text"
            placeholder="Location (Dubai Area)"
            v-model="form.location"
            required
          />

          <select v-model="form.service" required>

            <option disabled value="">
              Select Service
            </option>

            <option>AC Maintenance</option>
            <option>Plumbing</option>
            <option>Electrical</option>
            <option>Home Maintenance</option>
            <option>Soil Work</option>
            <option>Media Wall</option>

          </select>

          <textarea
            rows="5"
            placeholder="Describe your requirement..."
            v-model="form.message"
            required
          ></textarea>

          <p v-if="errorMessage" class="form-error">{{ errorMessage }}</p>

          <button type="submit" :disabled="submitting">
            {{ submitting ? 'Submitting...' : 'Request Free Quote' }}
          </button>

        </form>

      </div>

    </div>

  </section>
</template>

<script setup>
import { reactive, ref } from "vue";
import api from "@/services/api";

const form = reactive({
  name: "",
  phone: "",
  email: "",
  location: "",
  service: "",
  message: ""
});

const submitting = ref(false);
const errorMessage = ref("");

const submitForm = async () => {
  errorMessage.value = "";
  submitting.value = true;

  try {
    await api.submitQuote({ ...form });

    alert("Quote Request Submitted Successfully!");

    form.name = "";
    form.phone = "";
    form.email = "";
    form.location = "";
    form.service = "";
    form.message = "";
  } catch (err) {
    errorMessage.value = err.message || "Something went wrong. Please try again.";
  } finally {
    submitting.value = false;
  }
};
</script>

<style scoped>

.quote-section{

padding:100px 8%;

background:#081A38;

}

.quote-container{

display:grid;

grid-template-columns:1fr 1fr;

gap:60px;

align-items:center;

}

.quote-content{

color:white;

}

.subtitle{

color:#ff6b00;

font-weight:bold;

letter-spacing:2px;

}

.quote-content h2{

font-size:46px;

margin:20px 0;

line-height:1.3;

}

.quote-content p{

color:#ddd;

line-height:1.8;

margin-bottom:35px;

}

.benefits{

display:grid;

grid-template-columns:1fr 1fr;

gap:18px;

}

.benefit{

background:rgba(255,255,255,.08);

padding:16px;

border-radius:10px;

}

.quote-form{

background:white;

padding:40px;

border-radius:20px;

box-shadow:0 20px 40px rgba(0,0,0,.2);

}

.quote-form h3{

font-size:28px;

margin-bottom:25px;

color:#081A38;

}

.quote-form input,
.quote-form select,
.quote-form textarea{

width:100%;

padding:15px;

margin-bottom:18px;

border:1px solid #ddd;

border-radius:10px;

font-size:15px;

outline:none;

}

.quote-form input:focus,
.quote-form select:focus,
.quote-form textarea:focus{

border-color:#ff6b00;

}

.quote-form button{

width:100%;

padding:16px;

border:none;

background:#ff6b00;

color:white;

font-size:17px;

font-weight:bold;

border-radius:10px;

cursor:pointer;

transition:.3s;

}

.quote-form button:hover{

background:#e55d00;

}

.quote-form button:disabled{

background:#ffb380;
cursor:not-allowed;

}

.quote-form .form-error{

color:#d92d20;
background:#fdecea;
padding:12px 15px;
border-radius:10px;
font-size:14px;
margin:-4px 0 18px;

}

@media(max-width:992px){

.quote-container{

grid-template-columns:1fr;

}

.quote-content{

text-align:center;

}

.benefits{

grid-template-columns:1fr;

}

.quote-content h2{

font-size:34px;

}

}

</style>