<template>
  <div class="service-card">

    <img v-if="image" :src="image" :alt="title">
    <div v-else class="image-fallback">
      <i v-if="isIconClass" :class="icon"></i>
      <span v-else>{{ icon || '🔧' }}</span>
    </div>

    <div class="content">

      <div class="icon" v-if="image">
        <i v-if="isIconClass" :class="icon"></i>
        <span v-else>{{ icon }}</span>
      </div>

      <h3>{{ title }}</h3>

      <p>{{ description }}</p>

      <button
        class="learn-btn"
        @click="viewService"
      >
        Learn More →
      </button>

    </div>

  </div>
</template>

<script setup>

import { computed } from "vue"

const props = defineProps({

  title:String,
  icon:String,
  image:String,
  description:String,
  link:String

})

// The icon field can be an emoji ("🔧"), a FontAwesome class ("fa-solid fa-fan"),
// or left blank. Only render it as an <i> tag when it looks like a FA class.
const isIconClass = computed(() => Boolean(props.icon && props.icon.startsWith("fa-")))

const emit = defineEmits(["view-service"])

const viewService = () => {

  emit("view-service", props.link)

}

</script>

<style scoped>

.image-fallback{

height:220px;
display:flex;
align-items:center;
justify-content:center;
background:linear-gradient(135deg,#081A38,#0f2a56);
color:#ff6b00;
font-size:44px;

}

</style>