<template>
  <nav class="admin-sidebar">
    <div class="brand">
      <span class="brand-mark">EF</span>
      <div>
        <strong>EliteFix</strong>
        <small>Admin Panel</small>
      </div>
    </div>

    <ul class="nav flex-column admin-nav">
      <li class="nav-item">
        <RouterLink to="/admin/dashboard" class="nav-link" active-class="active">
          <i class="fa-solid fa-gauge"></i> Dashboard
        </RouterLink>
      </li>
      <li class="nav-item">
        <RouterLink to="/admin/quotes" class="nav-link" active-class="active">
          <i class="fa-solid fa-file-invoice"></i> View Quotes
        </RouterLink>
      </li>
      <li class="nav-item">
        <RouterLink to="/admin/services" class="nav-link" active-class="active">
          <i class="fa-solid fa-screwdriver-wrench"></i> Manage Services
        </RouterLink>
      </li>
    </ul>

    <div class="sidebar-footer">
      <div class="admin-identity" v-if="adminName">
        Signed in as <strong>{{ adminName }}</strong>
      </div>
      <button class="btn btn-outline-light btn-sm w-100" @click="handleLogout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </button>
    </div>
  </nav>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import adminService from '@/services/adminService'

const router = useRouter()

const adminName = computed(() => adminService.getStoredAdmin()?.name || '')

const handleLogout = () => {
  adminService.logout()
  router.push('/admin/login')
}
</script>

<style scoped>
.admin-sidebar {
  background: #081a38;
  color: #fff;
  min-height: 100vh;
  padding: 24px 18px;
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
}

.brand {
  display: flex;
  align-items: center;
  gap: 12px;
  padding-bottom: 24px;
  margin-bottom: 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}

.brand-mark {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  background: #ff6b00;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  flex-shrink: 0;
}

.brand strong {
  display: block;
  font-size: 15px;
}

.brand small {
  color: #9fb0c9;
  font-size: 12px;
}

.admin-nav {
  flex: 1;
  gap: 4px;
}

.admin-nav .nav-link {
  color: #cdd8ea;
  padding: 12px 14px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14.5px;
  transition: 0.2s;
}

.admin-nav .nav-link i {
  width: 18px;
  text-align: center;
}

.admin-nav .nav-link:hover {
  background: rgba(255, 255, 255, 0.08);
  color: #fff;
}

.admin-nav .nav-link.active {
  background: #ff6b00;
  color: #fff;
}

.sidebar-footer {
  border-top: 1px solid rgba(255, 255, 255, 0.12);
  padding-top: 16px;
}

.admin-identity {
  font-size: 12.5px;
  color: #9fb0c9;
  margin-bottom: 10px;
}
</style>
