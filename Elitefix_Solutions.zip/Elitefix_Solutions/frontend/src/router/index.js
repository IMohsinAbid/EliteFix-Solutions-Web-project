import { createRouter, createWebHistory } from 'vue-router'

import Home from '../views/Home.vue'
import About from '../views/About.vue'
import Services from '../views/Services.vue'
import Gallery from '../views/Gallery.vue'
import Contact from '../views/Contact.vue'
import RequestQuote from '../views/RequestQuote.vue'

import AcMaintenance from '../views/AcMaintainance.vue'
import Plumbing from '../views/Plumbing.vue'
import Electrical from '../views/Electrical.vue'
import HomeMaintenance from '../views/HomeMaintainance.vue'
import SoilWork from '../views/SoilWork.vue'
import MediaWall from '../views/MediaWall.vue'

import AdminLogin from '../views/AdminLogin.vue'
import AdminDashboard from '../views/AdminDashboard.vue'
import AdminQuotes from '../views/AdminQuotes.vue'
import AdminServices from '../views/AdminServices.vue'
import adminService from '../services/adminService'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: Home
    },
    {
      path: '/about',
      component: About
    },
    {
      path: '/services',
      component: Services
    },
    {
      path: '/gallery',
      component: Gallery
    },
    {
      path: '/contact',
      component: Contact
    },
    {
      path: '/request-quote',
      component: RequestQuote
    },
    {
      path: '/services/ac-maintenance',
      component: AcMaintenance
    },
    {
      path: '/services/plumbing',
      component: Plumbing
    },
    {
      path: '/services/electrical',
      component: Electrical
    },
    {
      path: '/services/home-maintenance',
      component: HomeMaintenance
    },
    {
      path: '/services/soil-work',
      component: SoilWork
    },
    {
      path: '/services/media-wall',
      component: MediaWall
    },
    {
      path: '/admin/login',
      component: AdminLogin,
      meta: { guestOnly: true }
    },
    {
      path: '/admin/dashboard',
      component: AdminDashboard,
      meta: { requiresAuth: true }
    },
    {
      path: '/admin/quotes',
      component: AdminQuotes,
      meta: { requiresAuth: true }
    },
    {
      path: '/admin/services',
      component: AdminServices,
      meta: { requiresAuth: true }
    }
  ]
})

// Navigation guard: protects every /admin/* page except the login screen.
// - No JWT in localStorage -> redirect to /admin/login (remembering where they were headed)
// - Already logged in and visiting /admin/login -> send straight to the dashboard
// Invalid/expired tokens are caught server-side: the axios interceptor in
// axiosClient.js clears the session and redirects to /admin/login on any 401.
router.beforeEach((to) => {
  const isAuthenticated = adminService.isAuthenticated()

  if (to.meta.requiresAuth && !isAuthenticated) {
    return { path: '/admin/login', query: { redirect: to.fullPath } }
  }

  if (to.meta.guestOnly && isAuthenticated) {
    return { path: '/admin/dashboard' }
  }

  return true
})

export default router