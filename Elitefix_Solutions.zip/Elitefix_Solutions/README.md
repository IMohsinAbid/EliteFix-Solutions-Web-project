# EliteFix Solutions — Full Stack Setup

This project now has two parts:

```
Elitefix Solutions/ElitefixSolutions/   → Vue 3 + Vite frontend (already existed)
backend/                                → NEW: Node/Express + MongoDB API
```

The **Request a Quote** form (on the Request Quote page and the reusable
`RequestQuoteSection` used on other pages) and the **Contact** form now submit
real data to the backend, which stores it in MongoDB.

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `backend/.env` and set `MONGODB_URI`:

- **Local MongoDB**: `mongodb://127.0.0.1:27017/elitefix`
- **MongoDB Atlas** (free tier is fine): create a cluster at
  https://www.mongodb.com/cloud/atlas, add a database user, allow your IP,
  then copy the connection string, e.g.
  `mongodb+srv://<user>:<password>@<cluster>.mongodb.net/elitefix?retryWrites=true&w=majority`

Then start the API:

```bash
npm run dev     # with nodemon, auto-restarts on changes
# or
npm start
```

You should see:

```
MongoDB connected: <host>/elitefix
EliteFix API listening on port 5000
```

Health check: `GET http://localhost:5000/api/health`

### API endpoints

| Method | Endpoint                    | Purpose                          |
|--------|------------------------------|-----------------------------------|
| POST   | `/api/quotes`                | Submit a quote request            |
| GET    | `/api/quotes`                | List all quote requests           |
| GET    | `/api/quotes/:id`            | Get a single quote request        |
| PATCH  | `/api/quotes/:id/status`     | Update status (new/contacted/closed) |
| DELETE | `/api/quotes/:id`            | Delete a quote request            |
| POST   | `/api/contact`               | Submit a contact message          |
| GET    | `/api/contact`               | List all contact messages         |
| PATCH  | `/api/contact/:id/status`    | Update status (new/read/closed)   |
| DELETE | `/api/contact/:id`           | Delete a contact message          |

All input is validated server-side (required fields, valid email, allowed
service values) and there's basic rate limiting on the form endpoints to
deter spam.

## 2. Frontend setup

```bash
cd "Elitefix Solutions/ElitefixSolutions"
npm install
cp .env.example .env
```

`VITE_API_URL` in `.env` should point at the backend (defaults to
`http://localhost:5000/api`, matching the backend's default port).

Run it:

```bash
npm run dev
```

Visit the site, go to **Request a Quote** or **Contact**, and submit a form —
it will POST to the Express API and save into MongoDB. You'll see a
success/error message inline on the form instead of a browser `alert()`.

## 3. Verifying data landed in MongoDB

Using the `mongosh` shell (or MongoDB Compass):

```bash
mongosh "mongodb://127.0.0.1:27017/elitefix"
> db.quotes.find().pretty()
> db.contacts.find().pretty()
```

(or open the equivalent collections in Compass/Atlas if you're using a
cloud cluster).

## What was added/changed

**New — `backend/`**
- `server.js` — Express app, CORS, JSON parsing, rate limiting, routes, error handling
- `config/db.js` — Mongoose connection to MongoDB
- `models/Quote.js`, `models/Contact.js` — Mongoose schemas
- `controllers/`, `routes/`, `middleware/validators.js` — CRUD logic + validation
- `.env.example` — configuration template

**Changed — frontend**
- `src/services/api.js` (new) — small fetch wrapper used by all three forms
- `src/views/RequestQuote.vue` — now calls the API, shows loading/success/error states
- `src/views/Contact.vue` — form previously had **no `v-model` bindings and no submit
  handler at all**; now fully wired up and calls the API
- `src/components/RequestQuoteSection.vue` — wired to the API; added a required
  `location` field (needed by the backend) and aligned its service dropdown
  values with the other forms so validation passes consistently
- `.env.example` (new) — `VITE_API_URL` config

Nothing about the existing visual design was changed — only form behavior.
