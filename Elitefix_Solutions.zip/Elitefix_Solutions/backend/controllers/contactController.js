const { validationResult } = require('express-validator')
const Contact = require('../models/Contact')

// @route  POST /api/contact
// @desc   Create a new contact message
const createContact = async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { name, email, phone, service, message } = req.body

    const contact = await Contact.create({ name, email, phone, service, message })

    return res.status(201).json({
      success: true,
      message: 'Message sent successfully!',
      data: contact,
    })
  } catch (err) {
    console.error('Error creating contact message:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  GET /api/contact
// @desc   List all contact messages (admin use)
const getContacts = async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ createdAt: -1 })
    return res.status(200).json({ success: true, count: contacts.length, data: contacts })
  } catch (err) {
    console.error('Error fetching contacts:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  PATCH /api/contact/:id/status
const updateContactStatus = async (req, res) => {
  try {
    const { status } = req.body
    const contact = await Contact.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    )
    if (!contact) {
      return res.status(404).json({ success: false, message: 'Message not found' })
    }
    return res.status(200).json({ success: true, data: contact })
  } catch (err) {
    console.error('Error updating contact:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  DELETE /api/contact/:id
const deleteContact = async (req, res) => {
  try {
    const contact = await Contact.findByIdAndDelete(req.params.id)
    if (!contact) {
      return res.status(404).json({ success: false, message: 'Message not found' })
    }
    return res.status(200).json({ success: true, message: 'Message deleted' })
  } catch (err) {
    console.error('Error deleting contact:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

module.exports = {
  createContact,
  getContacts,
  updateContactStatus,
  deleteContact,
}
