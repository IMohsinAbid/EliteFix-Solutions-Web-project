const { validationResult } = require('express-validator')
const Admin = require('../models/Admin')
const Quote = require('../models/Quote')
const Service = require('../models/Service')
const generateToken = require('../utils/generateToken')

// @route  POST /api/admin/login
// @desc   Authenticate an admin and return a JWT
// @access Public
const loginAdmin = async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { email, password } = req.body

    // Password has `select: false` on the schema, so it must be explicitly requested.
    const admin = await Admin.findOne({ email: email.toLowerCase().trim() }).select('+password')

    // Use the same generic message whether the email doesn't exist or the
    // password is wrong, so we don't leak which admin emails are registered.
    if (!admin || !(await admin.matchPassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' })
    }

    const token = generateToken(admin._id)

    return res.status(200).json({
      success: true,
      message: 'Login successful',
      token,
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
      },
    })
  } catch (err) {
    console.error('Error logging in admin:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  GET /api/admin/me
// @desc   Return the currently authenticated admin (used by the frontend to
//         verify a stored token is still valid on app load)
// @access Private
const getCurrentAdmin = async (req, res) => {
  return res.status(200).json({
    success: true,
    admin: {
      id: req.admin._id,
      name: req.admin.name,
      email: req.admin.email,
    },
  })
}

// @route  GET /api/admin/stats
// @desc   Counts that power the dashboard cards
// @access Private
const getDashboardStats = async (req, res) => {
  try {
    const [totalQuotes, totalServices, pendingQuotes] = await Promise.all([
      Quote.countDocuments(),
      Service.countDocuments(),
      Quote.countDocuments({ status: 'new' }),
    ])

    return res.status(200).json({
      success: true,
      data: { totalQuotes, totalServices, pendingQuotes },
    })
  } catch (err) {
    console.error('Error fetching dashboard stats:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

module.exports = { loginAdmin, getCurrentAdmin, getDashboardStats }
