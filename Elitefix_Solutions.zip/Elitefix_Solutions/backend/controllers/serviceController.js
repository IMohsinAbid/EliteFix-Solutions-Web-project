const { validationResult } = require('express-validator')
const Service = require('../models/Service')

// @route  GET /api/services
// @desc   List all services
// @access Public (the public-facing site can use this too; admin-only actions
//         like create/delete are protected individually below)
const getServices = async (req, res) => {
  try {
    const services = await Service.find().sort({ createdAt: -1 })
    return res.status(200).json({ success: true, count: services.length, data: services })
  } catch (err) {
    console.error('Error fetching services:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  POST /api/services
// @desc   Add a new service
// @access Private (admin)
const createService = async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { name, description, icon, price } = req.body
    const service = await Service.create({ name, description, icon, price })

    return res.status(201).json({ success: true, message: 'Service added successfully!', data: service })
  } catch (err) {
    console.error('Error creating service:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  PATCH /api/services/:id
// @desc   Update a service
// @access Private (admin)
const updateService = async (req, res) => {
  try {
    const { name, description, icon, price } = req.body
    const service = await Service.findByIdAndUpdate(
      req.params.id,
      { name, description, icon, price },
      { new: true, runValidators: true }
    )

    if (!service) {
      return res.status(404).json({ success: false, message: 'Service not found' })
    }

    return res.status(200).json({ success: true, data: service })
  } catch (err) {
    console.error('Error updating service:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  DELETE /api/services/:id
// @desc   Delete a service
// @access Private (admin)
const deleteService = async (req, res) => {
  try {
    const service = await Service.findByIdAndDelete(req.params.id)

    if (!service) {
      return res.status(404).json({ success: false, message: 'Service not found' })
    }

    return res.status(200).json({ success: true, message: 'Service deleted' })
  } catch (err) {
    console.error('Error deleting service:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

module.exports = { getServices, createService, updateService, deleteService }
