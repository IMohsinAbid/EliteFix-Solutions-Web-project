const { validationResult } = require('express-validator')
const Quote = require('../models/Quote')

// @route  POST /api/quotes
// @desc   Create a new quote request
const createQuote = async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { name, email, phone, location, service, message } = req.body

    const quote = await Quote.create({ name, email, phone, location, service, message })

    return res.status(201).json({
      success: true,
      message: 'Quote request submitted successfully!',
      data: quote,
    })
  } catch (err) {
    console.error('Error creating quote:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  GET /api/quotes?search=term
// @desc   List all quote requests (admin use), optionally filtered by a
//         case-insensitive match on name, email, or phone
const getQuotes = async (req, res) => {
  try {
    const { search } = req.query

    let filter = {}
    if (search && search.trim()) {
      const regex = new RegExp(search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i')
      filter = { $or: [{ name: regex }, { email: regex }, { phone: regex }] }
    }

    const quotes = await Quote.find(filter).sort({ createdAt: -1 })
    return res.status(200).json({ success: true, count: quotes.length, data: quotes })
  } catch (err) {
    console.error('Error fetching quotes:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  GET /api/quotes/:id
const getQuoteById = async (req, res) => {
  try {
    const quote = await Quote.findById(req.params.id)
    if (!quote) {
      return res.status(404).json({ success: false, message: 'Quote not found' })
    }
    return res.status(200).json({ success: true, data: quote })
  } catch (err) {
    console.error('Error fetching quote:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  PATCH /api/quotes/:id/status
const updateQuoteStatus = async (req, res) => {
  try {
    const { status } = req.body
    const quote = await Quote.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    )
    if (!quote) {
      return res.status(404).json({ success: false, message: 'Quote not found' })
    }
    return res.status(200).json({ success: true, data: quote })
  } catch (err) {
    console.error('Error updating quote:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

// @route  DELETE /api/quotes/:id
const deleteQuote = async (req, res) => {
  try {
    const quote = await Quote.findByIdAndDelete(req.params.id)
    if (!quote) {
      return res.status(404).json({ success: false, message: 'Quote not found' })
    }
    return res.status(200).json({ success: true, message: 'Quote deleted' })
  } catch (err) {
    console.error('Error deleting quote:', err.message)
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' })
  }
}

module.exports = {
  createQuote,
  getQuotes,
  getQuoteById,
  updateQuoteStatus,
  deleteQuote,
}
