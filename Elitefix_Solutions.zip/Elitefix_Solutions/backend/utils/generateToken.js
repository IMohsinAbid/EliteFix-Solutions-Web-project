const jwt = require('jsonwebtoken')

/**
 * Sign a short-lived JWT for an admin's id.
 * The token is what the frontend stores in localStorage and sends back
 * as `Authorization: Bearer <token>` on every protected request.
 */
const generateToken = (adminId) => {
  return jwt.sign({ id: adminId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  })
}

module.exports = generateToken
