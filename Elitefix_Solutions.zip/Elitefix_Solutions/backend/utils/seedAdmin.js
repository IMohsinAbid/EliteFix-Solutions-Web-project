/**
 * One-time setup script: creates the first Admin account so you can log in
 * to the admin panel. Reads credentials from your .env file.
 *
 * Usage:
 *   npm run seed:admin
 *
 * Add these to backend/.env before running:
 *   SEED_ADMIN_NAME=Admin
 *   SEED_ADMIN_EMAIL=admin@elitefixsolutions.com
 *   SEED_ADMIN_PASSWORD=change-this-password
 *
 * Safe to re-run: if an admin with that email already exists, it exits
 * without creating a duplicate or touching the existing password.
 */
require('dotenv').config()
const mongoose = require('mongoose')
const Admin = require('../models/Admin')

const run = async () => {
  const name = process.env.SEED_ADMIN_NAME || 'Admin'
  const email = process.env.SEED_ADMIN_EMAIL
  const password = process.env.SEED_ADMIN_PASSWORD

  if (!email || !password) {
    console.error(
      'Set SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD in backend/.env before running this script.'
    )
    process.exit(1)
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI)

    const existing = await Admin.findOne({ email: email.toLowerCase().trim() })
    if (existing) {
      console.log(`An admin with email "${email}" already exists. Nothing to do.`)
      process.exit(0)
    }

    // Password hashing happens automatically via the pre('save') hook on the model.
    await Admin.create({ name, email, password })

    console.log(`Admin account created for "${email}". You can now log in from /admin/login.`)
    process.exit(0)
  } catch (err) {
    console.error('Failed to seed admin:', err.message)
    process.exit(1)
  }
}

run()
