const express = require('express')
const router = express.Router()

const { loginAdmin, getCurrentAdmin, getDashboardStats } = require('../controllers/adminController')
const { adminLoginValidationRules } = require('../middleware/validators')
const { protect } = require('../middleware/authMiddleware')

router.post('/login', adminLoginValidationRules, loginAdmin)
router.get('/me', protect, getCurrentAdmin)
router.get('/stats', protect, getDashboardStats)

module.exports = router
