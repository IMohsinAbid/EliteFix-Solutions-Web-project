const express = require('express')
const router = express.Router()

const {
  createQuote,
  getQuotes,
  getQuoteById,
  updateQuoteStatus,
  deleteQuote,
} = require('../controllers/quoteController')
const { quoteValidationRules } = require('../middleware/validators')
const { protect } = require('../middleware/authMiddleware')

// Public: the "Request a Quote" form on the main site submits here.
router.post('/', quoteValidationRules, createQuote)

// Admin-only: viewing, updating, and deleting submitted quote requests.
router.get('/', protect, getQuotes)
router.get('/:id', protect, getQuoteById)
router.patch('/:id/status', protect, updateQuoteStatus)
router.delete('/:id', protect, deleteQuote)

module.exports = router
