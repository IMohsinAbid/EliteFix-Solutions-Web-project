const express = require('express')
const router = express.Router()

const {
  createContact,
  getContacts,
  updateContactStatus,
  deleteContact,
} = require('../controllers/contactController')
const { contactValidationRules } = require('../middleware/validators')

router.post('/', contactValidationRules, createContact)
router.get('/', getContacts)
router.patch('/:id/status', updateContactStatus)
router.delete('/:id', deleteContact)

module.exports = router
