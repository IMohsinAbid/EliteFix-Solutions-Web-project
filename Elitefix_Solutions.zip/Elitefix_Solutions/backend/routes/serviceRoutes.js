const express = require('express')
const router = express.Router()

const { getServices, createService, updateService, deleteService } = require('../controllers/serviceController')
const { serviceValidationRules } = require('../middleware/validators')
const { protect } = require('../middleware/authMiddleware')

// Public: the main site can list services.
router.get('/', getServices)

// Admin-only: creating, editing, and removing services.
router.post('/', protect, serviceValidationRules, createService)
router.patch('/:id', protect, updateService)
router.delete('/:id', protect, deleteService)

module.exports = router
