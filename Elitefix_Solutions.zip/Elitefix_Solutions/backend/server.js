require('dotenv').config()

const express = require('express')
const cors = require('cors')
const rateLimit = require('express-rate-limit')

const connectDB = require('./config/db')
const quoteRoutes = require('./routes/quoteRoutes')
const contactRoutes = require('./routes/contactRoutes')
const adminRoutes = require('./routes/adminRoutes')
const serviceRoutes = require('./routes/serviceRoutes')

const app = express()

// --- Database ---
connectDB()

// --- Core middleware ---
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const allowedOrigins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173')
  .split(',')
  .map((origin) => origin.trim())

app.use(
  cors({
    origin: allowedOrigins,
    methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  })
)

// Basic rate limiting on form-submission endpoints to deter spam/abuse
const formLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later.' },
})
app.use('/api/quotes', formLimiter)
app.use('/api/contact', formLimiter)

// Tighter limiter on the admin login endpoint to slow down brute-force attempts
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many login attempts, please try again later.' },
})
app.use('/api/admin/login', loginLimiter)

// --- Routes ---
app.get('/api/health', (req, res) => {
  res.status(200).json({ success: true, message: 'EliteFix API is running' })
})

app.use('/api/quotes', quoteRoutes)
app.use('/api/contact', contactRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/services', serviceRoutes)

// --- 404 handler ---
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' })
})

// --- Global error handler ---
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ success: false, message: 'Something went wrong on the server.' })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`EliteFix API listening on port ${PORT}`)
})
