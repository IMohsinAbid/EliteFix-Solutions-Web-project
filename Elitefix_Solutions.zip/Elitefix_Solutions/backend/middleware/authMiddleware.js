const jwt = require('jsonwebtoken')
const Admin = require('../models/Admin')

/**
 * Protects a route: requires a valid `Authorization: Bearer <token>` header.
 * - No token / malformed header -> 401
 * - Token invalid or expired    -> 401
 * - Token valid but admin no longer exists -> 401
 * On success, attaches the admin document (without password) to req.admin.
 */
const protect = async (req, res, next) => {
  let token

  const authHeader = req.headers.authorization

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1]
  }

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token provided' })
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    const admin = await Admin.findById(decoded.id)
    if (!admin) {
      return res.status(401).json({ success: false, message: 'Not authorized, admin no longer exists' })
    }

    req.admin = admin
    next()
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Not authorized, invalid or expired token' })
  }
}

module.exports = { protect }
