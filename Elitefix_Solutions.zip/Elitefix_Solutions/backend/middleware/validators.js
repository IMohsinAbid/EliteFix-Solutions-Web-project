const { body } = require('express-validator')
const { QUOTE_SERVICES } = require('../models/Quote')

const quoteValidationRules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
  body('email').trim().notEmpty().withMessage('Email is required').isEmail().withMessage('Invalid email address'),
  body('phone').trim().notEmpty().withMessage('Phone number is required').isLength({ max: 30 }),
  body('location').trim().notEmpty().withMessage('Location is required').isLength({ max: 150 }),
  body('service')
    .trim()
    .notEmpty()
    .withMessage('Service is required')
    .isIn(QUOTE_SERVICES)
    .withMessage('Invalid service selected'),
  body('message').trim().notEmpty().withMessage('Message is required').isLength({ max: 2000 }),
]

const contactValidationRules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
  body('email').trim().notEmpty().withMessage('Email is required').isEmail().withMessage('Invalid email address'),
  body('phone').trim().notEmpty().withMessage('Phone number is required').isLength({ max: 30 }),
  body('service').optional({ checkFalsy: true }).trim().isLength({ max: 60 }),
  body('message').trim().notEmpty().withMessage('Message is required').isLength({ max: 2000 }),
]

const adminLoginValidationRules = [
  body('email').trim().notEmpty().withMessage('Email is required').isEmail().withMessage('Invalid email address'),
  body('password').notEmpty().withMessage('Password is required'),
]

const serviceValidationRules = [
  body('name').trim().notEmpty().withMessage('Service name is required').isLength({ max: 120 }),
  body('description').trim().notEmpty().withMessage('Description is required').isLength({ max: 2000 }),
  body('icon').optional({ checkFalsy: true }).trim().isLength({ max: 500 }),
  body('price')
    .optional({ checkFalsy: true })
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
]

module.exports = {
  quoteValidationRules,
  contactValidationRules,
  adminLoginValidationRules,
  serviceValidationRules,
}
