const mongoose = require('mongoose')

const QUOTE_SERVICES = [
  'AC Maintenance',
  'Plumbing',
  'Electrical',
  'Home Maintenance',
  'Soil Work',
  'Media Wall',
]

const quoteSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 100 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 150 },
    phone: { type: String, required: true, trim: true, maxlength: 30 },
    location: { type: String, required: true, trim: true, maxlength: 150 },
    service: { type: String, required: true, enum: QUOTE_SERVICES },
    message: { type: String, required: true, trim: true, maxlength: 2000 },
    status: {
      type: String,
      enum: ['new', 'contacted', 'closed'],
      default: 'new',
    },
  },
  { timestamps: true }
)

module.exports = mongoose.model('Quote', quoteSchema)
module.exports.QUOTE_SERVICES = QUOTE_SERVICES
