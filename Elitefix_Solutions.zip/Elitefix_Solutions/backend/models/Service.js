const mongoose = require('mongoose')

const serviceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, required: true, trim: true, maxlength: 2000 },
    icon: { type: String, trim: true, maxlength: 500 }, // icon class (e.g. "fa-solid fa-fan") or an image URL
    price: { type: Number, min: 0 }, // optional, e.g. "starting from" price
  },
  { timestamps: true }
)

module.exports = mongoose.model('Service', serviceSchema)
