const mongoose = require('mongoose')

const CONTACT_SERVICES = [
  'Select Service',
  'AC Maintenance',
  'Plumbing',
  'Electrical',
  'Home Maintenance',
  'Soil Work',
  'Media Wall',
]

const contactSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 100 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 150 },
    phone: { type: String, required: true, trim: true, maxlength: 30 },
    service: { type: String, default: 'Select Service' },
    message: { type: String, required: true, trim: true, maxlength: 2000 },
    status: {
      type: String,
      enum: ['new', 'read', 'closed'],
      default: 'new',
    },
  },
  { timestamps: true }
)

module.exports = mongoose.model('Contact', contactSchema)
module.exports.CONTACT_SERVICES = CONTACT_SERVICES
